"use client";

import React, {
  useState,
  useEffect,
  useMemo,
  useRef,
  useCallback,
} from "react";
import Script from "next/script";
import { X, ShoppingBag, Truck } from "lucide-react";
import clsx from "clsx";
import QRCode from "react-qr-code";
import { useSession } from "@supabase/auth-helpers-react";
import { toZonedTime } from "date-fns-tz";
import useIsClient from "@/lib/useIsClient";
import useCartStore from "@/store/cartStore";
import AddressAutocomplete from "@/components/menu/AddressAutocomplete";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
import { useIsMobile } from "./checkoutModal/hooks";
import { ChopsticksControl } from "./checkoutModal/ChopsticksControl";
import { ProductItem } from "./checkoutModal/ProductItem";
import { PromoSection } from "./checkoutModal/PromoSection";
import {
  CITY_REVIEW_QR_URLS,
  DEFAULT_PACKAGING_COST,
  DEFAULT_REQUIRE_AUTOCOMPLETE,
  LOYALTY_REWARD_PERCENT_COUNT,
  MIN_SCHEDULE_MINUTES,
  SLOT_STEP_MINUTES,
  TERMS_VERSION,
  THANKS_QR_URL,
  TURNSTILE_SITE_KEY,
  accentBtn,
  buildClientDeliveryTime,
  buildSetSwapsNote,
  buildSetSwapsPayload,
  computeAddonsCostWithSauces,
  getRestaurantCityFromPath,
  getRestaurantPhone,
  isDateTimeBlocked,
  isOpenForSchedule,
  isVisible,
  minutesToHHMM,
  normalizeCheckoutConfig,
  resolveScheduleForSlug,
  roundUpToStep,
  safeFetch,
  supabase,
  tz,
  withCategoryPrefix,
} from "./checkoutModal/shared";
import type {
  ApplyScope,
  BlockedTime,
  CheckoutConfig,
  DbProductOptions,
  DiscountCodeRow,
  LoyaltyChoice,
  OrderOption,
  ProductDb,
  Promo,
  Zone,
} from "./checkoutModal/shared";


export default function CheckoutModal() {
  const isClient = useIsClient();
  const session = useSession();
  const isLoggedIn = !!session?.user;
  const supabaseAuth = createClientComponentClient();

  const {
    isCheckoutOpen,
    closeCheckoutModal: originalCloseCheckoutModal,
    checkoutStep,
    goToStep,
    nextStep,
    items,
    clearCart,
    removeItem,
    removeWholeItem,
    addAddon,
    removeAddon,
    swapIngredient,
  } = useCartStore();

  const isMobile = useIsMobile();

  // zamiast useSearchParams – czytamy query przez window.location.search
  const [reservationId, setReservationId] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    const r = params.get("reservation");
    if (!r) {
      setReservationId(null);
      return;
    }
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
      r.trim()
    );
    setReservationId(isUuid ? r.trim() : null);
  }, []);

const [notes, setNotes] = useState<Record<string, string>>({});
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [contactEmail, setContactEmail] = useState("");

 // START: getItemKey NEW (stabilny)
const getItemKey = (it: any, idx: number) => {
  const direct =
    it?.cart_item_id ??
    it?.cartId ??
    it?.cart_id ??
    it?.uid ??
    it?.uuid ??
    it?.id;

  if (direct != null) return String(direct);

  const pid = it?.product_id ?? it?.productId ?? it?.name ?? "item";
  const vid = it?.variant_id ?? it?.variantId ?? "base";
  return `${String(pid)}__${String(vid)}__${idx}`;
};
// END: getItemKey NEW



  const [street, setStreet] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [city, setCity] = useState("");
  const [flatNumber, setFlatNumber] = useState("");
  const [optionalAddress, setOptionalAddress] = useState("");

  const [selectedOption, setSelectedOption] = useState<OrderOption | null>(null);
  const [deliveryTimeOption, setDeliveryTimeOption] = useState<"asap" | "schedule">("asap");
const [scheduledTime, setScheduledTime] = useState<string>("");


  const [productsDb, setProductsDb] = useState<ProductDb[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [restLoc, setRestLoc] = useState<{ lat: number; lng: number } | null>(null);
  const [restaurantId, setRestaurantId] = useState<string | null>(null);
  const [deliveryInfo, setDeliveryInfo] = useState<{ cost: number; eta: string } | null>(null);

  const [legalAccepted, setLegalAccepted] = useState(false);
  const [promo, setPromo] = useState<Promo>(null);
  const [promoError, setPromoError] = useState<string | null>(null);

  const [tsReady, setTsReady] = useState(false);
  const [turnstileToken, setTurnstileToken] = useState<string | null>(null);
  const [turnstileError, setTurnstileError] = useState(false);
  const tsIdRef = useRef<any>(null);
  const tsMobileRef = useRef<HTMLDivElement | null>(null);
  const tsDesktopRef = useRef<HTMLDivElement | null>(null);
  

  const mobileSummaryRef = useRef<HTMLDivElement | null>(null);

const goNextFromStep3 = useCallback(() => {
  if (isMobile) {
    mobileSummaryRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    return;
  }
  nextStep();
}, [isMobile, nextStep]);


  const [deliveryMinOk, setDeliveryMinOk] = useState(true);
  const [deliveryMinRequired, setDeliveryMinRequired] = useState(0);
  const [outOfRange, setOutOfRange] = useState(false);
  const [custCoords, setCustCoords] = useState<{ lat: number; lng: number } | null>(null);

  // 2C) Reset stanów dostawy przy przełączeniu na "Na wynos"
const resetDeliveryState = useCallback(() => {
  // wyliczenia dostawy / walidacje stref
  setDeliveryInfo(null);
  setOutOfRange(false);
  setDeliveryMinOk(true);
  setDeliveryMinRequired(0);

  // koordynaty z Google (kluczowe, bo bez tego delivery powinno startować od zera)
  setCustCoords(null);

  // pola adresowe (żeby nie “wisiał” stary adres w tle)
  setStreet("");
  setPostalCode("");
  setCity("");
  setFlatNumber("");
}, []);

const handleSelectOption = useCallback(
  (opt: OrderOption) => {
    setSelectedOption(opt);

    if (opt === "takeaway") {
      resetDeliveryState();
      // (opcjonalnie) jeśli chcesz, żeby "na godzinę" też się resetowało przy na wynos:
      // setDeliveryTimeOption("asap");
      // setScheduledTime("");
    } else {
      // (opcjonalnie) jeśli przechodzisz na dostawę, możesz czyścić pole uwag do odbioru:
      // setOptionalAddress("");
    }
  },
  [resetDeliveryState]
);


  const sessionEmail = session?.user?.email || "";
  const effectiveEmail = (contactEmail || sessionEmail).trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const validEmail = emailRegex.test(effectiveEmail);

  const { slug: restaurantSlug, label: restaurantCityLabel } = getRestaurantCityFromPath();
  const thanksQrUrl = CITY_REVIEW_QR_URLS[restaurantSlug] || THANKS_QR_URL;
  const restaurantPhone = getRestaurantPhone(restaurantSlug);

  const [checkoutConfig, setCheckoutConfig] = useState<CheckoutConfig | null>(null);

    // DB options (warianty / modyfikatory) per produkt
  const [dbOptionsByProductId, setDbOptionsByProductId] = useState<Record<string, DbProductOptions>>({});

  useEffect(() => {
    if (!restaurantSlug || !isCheckoutOpen) {
      setDbOptionsByProductId({});
      return;
    }

    let cancelled = false;

    const load = async () => {
      try {
        const res = await fetch(
          `/api/public/product-options?restaurant=${encodeURIComponent(restaurantSlug)}`,
          { cache: "no-store" }
        );
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();

        const arr: DbProductOptions[] = Array.isArray(json?.items) ? json.items : [];
        const map: Record<string, DbProductOptions> = {};
        for (const it of arr) {
          if (it?.product_id) map[String(it.product_id)] = it;
        }

        if (!cancelled) setDbOptionsByProductId(map);
      } catch {
        if (!cancelled) setDbOptionsByProductId({});
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [restaurantSlug, isCheckoutOpen]);


const requireAutocomplete =
  checkoutConfig?.requireAutocomplete ?? DEFAULT_REQUIRE_AUTOCOMPLETE;

const packagingUnit =
  checkoutConfig?.packagingCost ?? DEFAULT_PACKAGING_COST;

const minScheduleMinutes =
  checkoutConfig?.minScheduleMinutes ?? MIN_SCHEDULE_MINUTES;

const slotStepMinutes =
  checkoutConfig?.slotStepMinutes ?? SLOT_STEP_MINUTES;


const scheduleDef = useMemo(
  () => resolveScheduleForSlug(restaurantSlug, checkoutConfig),
  [restaurantSlug, checkoutConfig]
);

const openInfo = useMemo(
  () => isOpenForSchedule(scheduleDef),
  [scheduleDef]
);


  /** Blokady godzin dla aktualnej restauracji */
const [blockedTimes, setBlockedTimes] = useState<BlockedTime[]>([]);

const scheduleSlots = useMemo(() => {
  if (!isCheckoutOpen) return [];
  const r = openInfo.range;
  if (!r) return [];

  const nowZoned = toZonedTime(new Date(), tz);
  const nowMins = nowZoned.getHours() * 60 + nowZoned.getMinutes();

  const openMins = r[0] * 60 + r[1];
  const closeMins = r[2] * 60 + r[3];

  // min: teraz + MIN_SCHEDULE_MINUTES, ale nie wcześniej niż otwarcie
  const minAllowedRaw = Math.max(openMins, nowMins + minScheduleMinutes);
const step = slotStepMinutes;
  const minAllowed = Math.ceil(minAllowedRaw / step) * step;

  if (minAllowed > closeMins) return [];

  const out: string[] = [];
  const base = new Date(nowZoned);

  for (let m = minAllowed; m <= closeMins; m += step) {
    const hh = Math.floor(m / 60);
    const mm = m % 60;

    const dt = new Date(base);
    dt.setHours(hh, mm, 0, 0);

    // filtr blokad z panelu
    if (isDateTimeBlocked(dt, blockedTimes)) continue;

    out.push(minutesToHHMM(m));
  }

  return out;
}, [isCheckoutOpen, openInfo.range, blockedTimes, minScheduleMinutes, slotStepMinutes]);

const canSchedule = scheduleSlots.length > 0;

const [loyaltyStickers, setLoyaltyStickers] = useState<number | null>(null);
const [loyaltyChoice, setLoyaltyChoice] = useState<LoyaltyChoice>("keep");
const [loyaltyLoading, setLoyaltyLoading] = useState(false);


  useEffect(() => {
  if (deliveryTimeOption !== "schedule") return;

  // jeśli brak slotów – nie pozwalamy na "Na godzinę"
  if (scheduleSlots.length === 0) {
    setDeliveryTimeOption("asap");
    return;
  }

  setScheduledTime((prev) => (scheduleSlots.includes(prev) ? prev : scheduleSlots[0]));
}, [deliveryTimeOption, scheduleSlots]);

  useEffect(() => {
    if (isLoggedIn && session) {
      setName(session.user.user_metadata?.full_name || "");
      setPhone(session.user.user_metadata?.phone || "");
      setContactEmail(session.user.email || "");
      setStreet(session.user.user_metadata?.street || "");
      setPostalCode(session.user.user_metadata?.postal_code || "");
      setCity(session.user.user_metadata?.city || "");
      setFlatNumber(session.user.user_metadata?.flat_number || "");
    }
  }, [isLoggedIn, session]);

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      // Jeżeli nie ma sluga (np. strona główna) – bierz wszystkie produkty jak do tej pory
      if (!restaurantSlug) {
        const prodRes = await supabase
          .from("products")
          .select(`
    id, name, subcategory, description, restaurant_id,
    product_option_groups (
        option_group:option_groups (
            id, name, type, min_select, max_select,
            options ( id, name, price_modifier, position )
        )
    )
`);

        if (!cancelled && !prodRes.error && prodRes.data) {
  // Rzutujemy na 'any', żeby TypeScript nie marudził o zagnieżdżone tabele
  setProductsDb((prodRes.data as any) || []);
}
        return;
      }

      // 1) restauracja po slugu
      const restRes = await supabase
        .from("restaurants")
        .select("id, lat, lng")
        .eq("slug", restaurantSlug)
        .maybeSingle();

      if (cancelled || restRes.error || !restRes.data) return;
      const rest: any = restRes.data;

      if (!cancelled) {
        if (rest.lat && rest.lng) {
          setRestLoc({ lat: rest.lat, lng: rest.lng });
        }
        setRestaurantId(rest.id as string);
      }

      // 2) dane zależne od restauracji: produkty + strefy dostawy
      const [prodRes, dzRes] = await Promise.all([
        supabase
          .from("products")
          .select(`
            id, name, subcategory, description, restaurant_id,
            product_option_groups (
              option_group:option_groups (
                id, name, type, min_select, max_select,
                options ( id, name, price_modifier, position )
              )
            )
          `)
          .eq("restaurant_id", rest.id),
        supabase
          .from("delivery_zones")
          .select("*")
          .eq("restaurant_id", rest.id)
          .order("min_distance_km", { ascending: true }),
      ]);

      if (!cancelled && !prodRes.error && prodRes.data) {
        setProductsDb((prodRes.data as any) || []);
      }
      if (!cancelled && !dzRes.error && dzRes.data) {
        setZones(dzRes.data as Zone[]);
      }
    };

    load();

    return () => {
      cancelled = true;
    };
  }, [restaurantSlug]);

  // Pobranie blokad godzin dla aktualnej restauracji (tylko gdy modal otwarty)
useEffect(() => {
  if (!restaurantSlug || !isCheckoutOpen) {
    setBlockedTimes([]);
    return;
  }

  let cancelled = false;

  const loadBlocked = async () => {
    try {
      const res = await fetch(
        `/api/admin/blocked-times?restaurant=${encodeURIComponent(
          restaurantSlug
        )}`,
        { cache: "no-store" }
      );

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const json = await res.json();

      // API może zwrócić [row] albo { items:[row] } – bierzemy bezpiecznie tablicę
      const raw: any[] = Array.isArray(json)
        ? json
        : Array.isArray((json as any)?.items)
        ? (json as any).items
        : [];

      if (cancelled) return;

      const mapped: BlockedTime[] = raw.map((row: any) => ({
        id: String(row.id),
        date: row.date, // 'YYYY-MM-DD'
        full_day: !!row.full_day,
        // obsłużymy też nazwy time_from / time_to, jeśli tak jest w API
        from_time: row.from_time ?? row.time_from ?? null,
        to_time: row.to_time ?? row.time_to ?? null,
      }));

      setBlockedTimes(mapped);
    } catch (e) {
      console.error("Nie udało się pobrać blokad godzin", e);
      if (!cancelled) {
        setBlockedTimes([]);
      }
    }
  };

  loadBlocked();

  return () => {
    cancelled = true;
  };
}, [restaurantSlug, isCheckoutOpen]);

useEffect(() => {
  if (!restaurantSlug || !isCheckoutOpen) {
    setCheckoutConfig(null);
    return;
  }

  let cancelled = false;
  const ac = new AbortController();

  const load = async () => {
    try {
      // DOSTOSUJ ŚCIEŻKĘ jeśli masz inną.
      const res = await fetch(
        `/api/public/checkout-config?restaurant=${encodeURIComponent(restaurantSlug)}`,
        { cache: "no-store", signal: ac.signal }
      );

      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const json = await res.json();
      const cfg = normalizeCheckoutConfig(json);

      if (!cancelled) setCheckoutConfig(cfg);
    } catch {
      // fallback: zostaje null, czyli leci Twoja obecna logika
      if (!cancelled) setCheckoutConfig(null);
    }
  };

  load();

  return () => {
    cancelled = true;
    ac.abort();
  };
}, [restaurantSlug, isCheckoutOpen]);


     useEffect(() => {
  // jeśli modal zamknięty albo user niezalogowany – czyścimy stan
  if (!isCheckoutOpen || !isLoggedIn || !session?.user?.id) {
    setLoyaltyStickers(null);
    setLoyaltyChoice("keep");
    return;
  }

  let cancelled = false;

  const load = async () => {
    try {
      setLoyaltyLoading(true);

      const { data, error } = await supabaseAuth
        .from("loyalty_accounts")
        .select("stickers")
        .eq("user_id", session.user.id)
        .maybeSingle();

      if (cancelled) return;
      if (error) throw error;

      const stickers = Math.max(
        0,
        Math.min(LOYALTY_REWARD_PERCENT_COUNT, Number(data?.stickers ?? 0))
      );

      setLoyaltyStickers(stickers);
      setLoyaltyChoice("keep");
    } catch (e) {
      console.error("Loyalty: błąd pobierania loyalty_accounts", e);
      if (!cancelled) {
        setLoyaltyStickers(0);
        setLoyaltyChoice("keep");
      }
    } finally {
      if (!cancelled) setLoyaltyLoading(false);
    }
  };

  load();

  return () => {
    cancelled = true;
  };
}, [isCheckoutOpen, isLoggedIn, session?.user?.id, supabaseAuth]);


  const [submitting, setSubmitting] = useState(false);
  const [confirmCityOk, setConfirmCityOk] = useState(false);
  const [orderSent, setOrderSent] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [chopsticksQty, setChopsticksQty] = useState<number>(0);

  const getTurnstileToken = useCallback((): string | null => {
  if (!TURNSTILE_SITE_KEY) return null;
  if (turnstileToken) return turnstileToken;

  // awaryjnie: czasem stan nie nadąża, a widget ma już response
  try {
    const t = window.turnstile?.getResponse?.(tsIdRef.current);
    return t ? String(t) : null;
  } catch {
    return null;
  }
}, [turnstileToken]);

const resetTurnstile = useCallback(() => {
  setTurnstileToken(null);
  setTurnstileError(false);
  try {
    if (window.turnstile && tsIdRef.current) {
      window.turnstile.reset(tsIdRef.current);
    }
  } catch {}
}, []);


  // Turnstile – remove jako useCallback
  const removeTurnstile = useCallback(() => {
    try {
      if (tsIdRef.current && window.turnstile) window.turnstile.remove(tsIdRef.current);
    } catch {}
    tsIdRef.current = null;
    setTurnstileToken(null);
    setTurnstileError(false);
  }, []);

  // Zamknięcie modala jako stabilny callback
  const closeCheckoutModal = useCallback(() => {
  // czyść koszyk tylko po udanym zamówieniu (żeby nie kasować „na X”)
  if (orderSent) {
    try {
      clearCart();
    } catch {}
  }

  originalCloseCheckoutModal();
  setPromo(null);
  setPromoError(null);
  setOrderSent(false);
  setNotes({});
  setErrorMessage(null);
  setConfirmCityOk(false);
  setLegalAccepted(false);
  setSubmitting(false);
  setLoyaltyChoice("keep");
  setLoyaltyStickers(null);
  setLoyaltyLoading(false);
  goToStep(1);
  removeTurnstile();
}, [originalCloseCheckoutModal, goToStep, removeTurnstile, orderSent, clearCart]);


  // ESC zamyka modal + blokada scrolla body
  useEffect(() => {
    if (!isCheckoutOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeCheckoutModal();
    window.addEventListener("keydown", onKey);
    const prevBody = document.body.style.overflow;
const prevHtml = document.documentElement.style.overflow;

document.body.style.overflow = "hidden";
document.documentElement.style.overflow = "hidden";

return () => {
  window.removeEventListener("keydown", onKey);
  document.body.style.overflow = prevBody;
  document.documentElement.style.overflow = prevHtml;
};
  }, [isCheckoutOpen, closeCheckoutModal]);

  // Turnstile – render jako useCallback
  const renderTurnstile = useCallback(
    (target: HTMLDivElement | null) => {
      if (!TURNSTILE_SITE_KEY || !window.turnstile || !isVisible(target)) return;
      try {
        setTurnstileError(false);
        tsIdRef.current = window.turnstile.render(target!, {
          sitekey: TURNSTILE_SITE_KEY,
          callback: (t: string) => setTurnstileToken(t),
          "error-callback": () => {
            setTurnstileToken(null);
            setTurnstileError(true);
          },
          "expired-callback": () => {
            setTurnstileToken(null);
            try {
              window.turnstile?.reset(tsIdRef.current);
            } catch {}
          },
          "timeout-callback": () => {
            setTurnstileToken(null);
            try {
              window.turnstile?.reset(tsIdRef.current);
            } catch {}
          },
          retry: "auto",
          theme: "auto",
          appearance: "always",
          ["refresh-expired"]: "auto",
        });
      } catch {
        setTurnstileError(true);
      }
    },
    []
  );

  // Turnstile – efekt z pełnymi dependencies
  useEffect(() => {
  if (!TURNSTILE_SITE_KEY || !tsReady) return;

  const shouldMount =
    isCheckoutOpen &&
    !orderSent &&
    (checkoutStep === 3 || (!isMobile && checkoutStep === 4));

  if (shouldMount) {
    renderTurnstile(tsMobileRef.current);
    renderTurnstile(tsDesktopRef.current);
    return;
  }

  removeTurnstile();
}, [
  isCheckoutOpen,
  checkoutStep,
  tsReady,
  orderSent,
  isMobile,
  renderTurnstile,
  removeTurnstile,
]);


  const productsByName = useMemo(() => {
    const map = new Map<string, ProductDb>();
    productsDb.forEach((p) => map.set(p.name, p));
    return map;
  }, [productsDb]);

  const productsById = useMemo(() => {
    const map = new Map<string, ProductDb>();
    productsDb.forEach((p) => map.set(p.id, p));
    return map;
  }, [productsDb]);

  const productCategory = useCallback(
    (name: string) => productsByName.get(name)?.subcategory || "",
    [productsByName]
  );

  const resolveProduct = useCallback(
    (item: any): ProductDb | undefined => {
      const pid = item.product_id ?? item.id;
      if (pid && productsById.get(pid)) {
        return productsById.get(pid);
      }
      if (item.baseName && productsByName.get(item.baseName)) {
        return productsByName.get(item.baseName);
      }
      if (item.name && productsByName.get(item.name)) {
        return productsByName.get(item.name);
      }
      return undefined;
    },
    [productsById, productsByName]
  );

  const optionsByCat = useMemo(() => {
    const out: Record<string, string[]> = {};

    productsDb.forEach((p) => {
      const cat = (p.subcategory || "").toLowerCase();
      if (!cat || cat === "specjały" || cat === "zestawy") return;

      const arr = (out[cat] ||= []);
      if (!arr.includes(p.name)) {
        // unikamy duplikatów nazw w obrębie kategorii
        arr.push(p.name);
      }
    });

    Object.values(out).forEach((arr) =>
      arr.sort((a, b) => a.localeCompare(b))
    );

    return out;
  }, [productsDb]);

  const baseTotal = useMemo<number>(() => {
    return items.reduce((acc: number, it: any) => {
      const qty = it.quantity || 1;
      const priceNum =
        typeof it.price === "string" ? parseFloat(it.price) : it.price || 0;
      const productDb = resolveProduct(it);
      const { addonsCost } = computeAddonsCostWithSauces({
  addons: it.addons ?? [],
  product: productDb ?? null,
  itemName: String(productDb?.name || it.name || ""),
  subcat: String((productDb?.subcategory || "") as string),
  restaurantSlug,
});
return acc + (priceNum + addonsCost) * qty;
    }, 0);
  }, [items, resolveProduct, restaurantSlug]);

  const packagingCost = selectedOption ? packagingUnit : 0;
  const subtotal = baseTotal + packagingCost;

  const getItemLineTotal = useCallback(
    (it: any) => {
      const qty = it.quantity || 1;
      const priceNum =
        typeof it.price === "string" ? parseFloat(it.price) : it.price || 0;
      const productDb = resolveProduct(it);
      const { addonsCost } = computeAddonsCostWithSauces({
  addons: it.addons ?? [],
  product: productDb ?? null,
  itemName: String(productDb?.name || it.name || ""),
  subcat: String((productDb?.subcategory || "") as string),
  restaurantSlug,
});
return (priceNum + addonsCost) * qty;
    }, [resolveProduct, restaurantSlug]);

  const isProductEligibleForPromo = useCallback(
    (prodDb: ProductDb, p: NonNullable<Promo>): boolean => {
      const norm = (s: string) => s.toLowerCase().trim();
      const scope = p.apply_scope || "all";
      const cat = norm(prodDb.subcategory || "");
      const name = norm(prodDb.name || "");
      const slug = name.replace(/\s+/g, "-");

      const matchAny = (list: string[] | null) => {
        if (!list || list.length === 0) return false;
        return list.some((raw) => {
          const token = norm(raw);
          if (!token) return false;
          return (
            cat === token ||
            name === token ||
            slug === token ||
            name.includes(token) ||
            slug.includes(token)
          );
        });
      };

      const inCatInclude = matchAny(p.include_categories);
      const inCatExclude = matchAny(p.exclude_categories);
      const inProdInclude = matchAny(p.include_products);
      const inProdExclude = matchAny(p.exclude_products);

      switch (scope) {
        case "include_categories":
          return inCatInclude;
        case "exclude_categories":
          return !inCatExclude;
        case "include_products":
          return inProdInclude;
        case "exclude_products":
          return !inProdExclude;
        case "all":
        default:
          if (inCatExclude || inProdExclude) return false;
          return true;
      }
    },
    []
  );

  const computeDiscountBase = useCallback(
    (p: NonNullable<Promo>): number => {
      return items.reduce((sum, it: any) => {
        const prodDb = resolveProduct(it);
        if (!prodDb) return sum;
        if (!isProductEligibleForPromo(prodDb, p)) return sum;
        const qty = it.quantity || 1;
        const priceNum =
          typeof it.price === "string" ? parseFloat(it.price) : it.price || 0;
        // UWAGA: rabat liczony tylko od ceny produktu (bez dodatków)
        return sum + priceNum * qty;
      }, 0);
    },
    [items, resolveProduct, isProductEligibleForPromo]
  );

  const calcDelivery = useCallback(
  async (custLat: number, custLng: number) => {
    if (!restLoc) return;

    try {
      const resp = await fetch(
        `/api/distance?origin=${restLoc.lat},${restLoc.lng}&destination=${custLat},${custLng}`
      );
      const { distance_km, error } = await resp.json();
      if (error) return;

      const zone = zones
        .filter((z) => z.active !== false)
        .find((z) => distance_km >= z.min_distance_km && distance_km <= z.max_distance_km);

      if (!zone) {
        setOutOfRange(true);
        setDeliveryMinOk(false);
        setDeliveryMinRequired(0);
        setDeliveryInfo({ cost: 0, eta: "Poza zasięgiem" });
        return;
      }

      setOutOfRange(false);

      const perKm =
        (zone.pricing_type ?? (zone.min_distance_km === 0 ? "flat" : "per_km")) === "per_km";
      let cost = perKm ? zone.cost * distance_km : zone.cost;

      if (zone.free_over != null && subtotal >= zone.free_over) cost = 0;

      const minOk = subtotal >= (zone.min_order_value || 0);
      setDeliveryMinOk(minOk);
      setDeliveryMinRequired(zone.min_order_value || 0);

      const eta = `${zone.eta_min_minutes}-${zone.eta_max_minutes} min`;
      const roundedDelivery = roundUpToStep(Math.max(0, cost), 0.5);
setDeliveryInfo({ cost: roundedDelivery, eta });
    } catch {
      // opcjonalnie: setDeliveryInfo(null)
    }
  },
  [restLoc, zones, subtotal]
);


  const onAddressSelect = (address: string, lat: number, lng: number) => {
    setStreet(address);
    if (lat && lng) {
      setCustCoords({ lat, lng });
      calcDelivery(lat, lng);
    }
  };

  useEffect(() => {
  if (selectedOption !== "delivery") return;
  if (!custCoords) return;
  calcDelivery(custCoords.lat, custCoords.lng);
}, [selectedOption, custCoords, calcDelivery]);

const deliveryCost =
  selectedOption === "delivery" ? (deliveryInfo?.cost || 0) : 0;



  const discount = useMemo(() => {
    if (!promo) return 0;
    const base = computeDiscountBase(promo as NonNullable<Promo>);
    if (base <= 0) return 0;
    const val =
      promo.type === "percent"
        ? base * (Number(promo.value) / 100)
        : Number(promo.value || 0);
   const totalCap = baseTotal + packagingCost + deliveryCost;
    return Math.max(0, Math.min(val, totalCap));
  }, [promo, computeDiscountBase, baseTotal, packagingCost, deliveryCost]);

  const canUseLoyalty4 =
  isLoggedIn &&
  typeof loyaltyStickers === "number" &&
  loyaltyStickers >= 4 &&
  loyaltyStickers < 8;
  
const hasAutoLoyaltyDiscount =
  isLoggedIn &&
  typeof loyaltyStickers === "number" &&
  loyaltyStickers >= 8;

const totalWithDelivery = Math.max(0, subtotal + deliveryCost - discount);
  const shouldHideOrderActions = Boolean(TURNSTILE_SITE_KEY && turnstileError);

  const productHelpers = {
    addAddon,
    removeAddon,
    swapIngredient,
    removeItem,
    removeWholeItem,
  };

  const guardEmail = () => {
    if (!validEmail) {
      setErrorMessage("Podaj poprawny adres e-mail – wyślemy potwierdzenie i link śledzenia.");
      return false;
    }
    return true;
  };

  const applyPromo = async (codeRaw: string) => {
    setPromoError(null);
    const code = codeRaw.trim();
    if (!code) return;
    if (!restaurantId) {
      setPromoError("Brak przypisanej restauracji do zamówienia.");
      return;
    }
    try {
      const { data, error } = await supabase
        .from("discount_codes")
        .select("*")
        .eq("restaurant_id", restaurantId)
        .eq("active", true)
        .eq("require_code", true)
        .ilike("code", code)
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        // fallback na ewentualny stary endpoint /api/promo/validate
        const currentTotal = baseTotal + packagingCost + (deliveryInfo?.cost || 0);
        const resp = await safeFetch("/api/promo/validate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code, total: currentTotal }),
        });
        if (resp?.valid) {
          const type = resp.type === "amount" ? "amount" : "percent";
          const valueNum = Number(resp.value || 0);
          if (valueNum <= 0) throw new Error("Nieprawidłowa wartość kodu.");
          const legacyPromo: NonNullable<Promo> = {
            id: "legacy",
            code: resp.code || code,
            type,
            value: valueNum,
            apply_scope: "all",
            include_categories: null,
            exclude_categories: null,
            include_products: null,
            exclude_products: null,
            min_order: null,
            require_code: true,
          };
          setPromo(legacyPromo);
          return;
        }
        throw new Error(resp?.message || "Kod nieprawidłowy.");
      }

      const row = data as DiscountCodeRow;
      const promoState = {
        id: row.id,
        code: row.code,
        type: row.type === "amount" ? "amount" : "percent",
        value: Number(row.value || 0),
        apply_scope: (row.apply_scope as ApplyScope) || "all",
        include_categories: row.include_categories || null,
        exclude_categories: row.exclude_categories || null,
        include_products: row.include_products || null,
        exclude_products: row.exclude_products || null,
        min_order: row.min_order,
        require_code: true,
      } as NonNullable<Promo>;

      if (promoState.value <= 0) {
        throw new Error("Nieprawidłowa wartość kodu.");
      }

      const baseForThis = computeDiscountBase(promoState);
      if (baseForThis <= 0) {
        throw new Error("Kod nie dotyczy żadnych produktów w koszyku.");
      }

      const now = new Date();
      if (row.expires_at && new Date(row.expires_at) < now) {
        throw new Error("Kod wygasł.");
      }

      if (
        typeof row.min_order === "number" &&
        row.min_order > 0 &&
        baseForThis < row.min_order
      ) {
        throw new Error(
          `Minimalna wartość zamówienia dla tego kodu to ${row.min_order.toFixed(
            2
          )} zł (liczona tylko z cen produktów).`
        );
      }

      setPromo(promoState);
    } catch (e: any) {
      setPromo(null);
      setPromoError(e.message || "Nie udało się zastosować kodu.");
    }
  };

  const clearPromo = () => {
    setPromo(null);
    setPromoError(null);
  };

  // Automatyczne promocje (require_code = false)
  useEffect(() => {
    if (!restaurantId || items.length === 0) {
      // przy pustym koszyku zostawiamy ewentualny ręczny kod, ale czyścimy auto
      setPromo((current) => (current && current.require_code ? current : null));
      return;
    }

    let cancelled = false;

    const loadAuto = async () => {
      try {
        const { data, error } = await supabase
          .from("discount_codes")
          .select("*")
          .eq("restaurant_id", restaurantId)
          .eq("active", true)
          .eq("require_code", false);

        if (error || !data) return;

        const rows = data as DiscountCodeRow[];
        let best: NonNullable<Promo> | null = null;
        let bestDiscount = 0;

        rows.forEach((row) => {
          const promoState = {
            id: row.id,
            code: row.code,
            type: row.type === "amount" ? "amount" : "percent",
            value: Number(row.value || 0),
            apply_scope: (row.apply_scope as ApplyScope) || "all",
            include_categories: row.include_categories || null,
            exclude_categories: row.exclude_categories || null,
            include_products: row.include_products || null,
            exclude_products: row.exclude_products || null,
            min_order: row.min_order,
            require_code: false,
          } as NonNullable<Promo>;

          if (promoState.value <= 0) return;

          const base = computeDiscountBase(promoState);
          if (base <= 0) return;

          const now = new Date();
          if (row.expires_at && new Date(row.expires_at) < now) return;

          if (
            typeof row.min_order === "number" &&
            row.min_order > 0 &&
            base < row.min_order
          ) {
            return;
          }

          const disc =
            promoState.type === "percent"
              ? base * (promoState.value / 100)
              : promoState.value;

          if (disc > bestDiscount) {
            bestDiscount = disc;
            best = promoState;
          }
        });

        if (cancelled) return;

        setPromo((current) => {
          // ręcznie wpisany kod ma priorytet
          if (current && current.require_code) return current;
          return best;
        });
      } catch {
        // brak auto-promki = cisza
      }
    };

    loadAuto();

    return () => {
      cancelled = true;
    };
  }, [restaurantId, items, computeDiscountBase]);

  const ensureFreshToken = async () => {
    if (!TURNSTILE_SITE_KEY) return true;
    if (turnstileToken) return true;
    try {
      if (window.turnstile && tsIdRef.current) window.turnstile.reset(tsIdRef.current);
      await new Promise((r) => setTimeout(r, 400));
      return !!turnstileToken;
    } catch {
      return false;
    }
  };

  const handleSubmitOrder = async () => {
    if (submitting) return;
    setErrorMessage(null);

    if (!items || items.length === 0) {
  setErrorMessage("Koszyk jest pusty.");
  return;
}

    if (!selectedOption) {
      setErrorMessage("Wybierz sposób odbioru.");
      return;
    }
    if (!legalAccepted) {
      setErrorMessage("Zaznacz akceptację regulaminu i polityki prywatności.");
      return;
    }
    if (!confirmCityOk) {
      setErrorMessage("Potwierdź miasto restauracji przed złożeniem zamówienia.");
      return;
    }

    const chk = isOpenForSchedule(scheduleDef);
    if (!chk.open) {
      setErrorMessage(
        `Zamówienia dla ${restaurantCityLabel} przyjmujemy dziś ${chk.label}.`
      );
      return;
    }

   if (deliveryTimeOption === "schedule" && selectedOption) {
    if (!scheduleSlots.includes(scheduledTime)) {
    setErrorMessage(
      "Wybrana godzina jest niedostępna. Wybierz jedną z dostępnych godzin."
    );
    return;
  }
  const [h, m] = scheduledTime.split(":").map(Number);
  if (!Number.isFinite(h) || !Number.isFinite(m)) {
    setErrorMessage(
      selectedOption === "delivery"
        ? "Podaj prawidłową godzinę dostawy."
        : "Podaj prawidłową godzinę odbioru."
    );
    return;
  }

  const nowZoned = toZonedTime(new Date(), tz);
  const dt = new Date(nowZoned);
  dt.setHours(h, m, 0, 0);

  // jeśli klient wybierze godzinę z przeszłości – traktujemy jako jutro
  if (dt.getTime() < nowZoned.getTime()) {
    dt.setDate(dt.getDate() + 1);
  }

  const diffMinutes = (dt.getTime() - nowZoned.getTime()) / 60000;
  if (diffMinutes < minScheduleMinutes) {
  setErrorMessage(
    `Przy wyborze realizacji „na godzinę” minimalny czas to ${minScheduleMinutes} minut od teraz.`
  );
  return;
}

  // NOWE: sprawdzenie blokad godzin z panelu admina
  if (isDateTimeBlocked(dt, blockedTimes)) {
    setErrorMessage(
      "Wybrana godzina jest niedostępna (zablokowana w systemie). Wybierz inną godzinę."
    );
    return;
  }
}

    if (!guardEmail()) return;
    const tsToken = getTurnstileToken();

if (TURNSTILE_SITE_KEY && !tsToken) {
  setErrorMessage("Zaznacz weryfikację antybot i spróbuj ponownie.");
  return;
}

    if (selectedOption === "delivery") {
      if (requireAutocomplete && !custCoords) {
        setErrorMessage(
          "Wybierz adres z listy (podpowiedzi Google), aby potwierdzić dostawę."
        );
        return;
      }
      if (outOfRange) {
        setErrorMessage("Adres jest poza zasięgiem dostawy.");
        return;
      }
      if (!deliveryMinOk) {
        setErrorMessage(
          `Minimalna wartość zamówienia dla tej strefy to ${deliveryMinRequired.toFixed(2)} zł.`
        );
        return;
      }
    }

    setSubmitting(true);
    try {
      const client_delivery_time = buildClientDeliveryTime(
  selectedOption,
  deliveryTimeOption,
  scheduledTime
);
const slug = restaurantSlug;

try {
  await fetch(`/api/restaurants/ensure-cookie?restaurant=${encodeURIComponent(slug)}`, {
    method: "GET",
    credentials: "same-origin",
  });
} catch {}

const orderPayload: any = {
  selected_option: selectedOption,
  payment_method:
    selectedOption === "delivery" ? "Gotówka u kierowcy" : "Gotówka przy odbiorze",
  user: isLoggedIn ? session!.user.id : null,
  name,
  phone,
  contact_email: effectiveEmail,
  delivery_cost: selectedOption === "delivery" ? (deliveryInfo?.cost || 0) : 0,
  packaging_cost: packagingCost,
  total_price: totalWithDelivery,
  discount_amount: discount || 0,
  promo_code: promo?.code || (promo && !promo.require_code ? "AUTO" : null),
  legal_accept: {
    terms_version: TERMS_VERSION,
    privacy_version: TERMS_VERSION,
    marketing_opt_in: false,
  },
  status: "placed",
  notice_payment:
    selectedOption === "delivery" ? "Płatność wyłącznie gotówką u kierowcy" : null,
  chopsticks_qty: Math.max(0, Math.min(10, Number(chopsticksQty) || 0)),
  reservation_id: reservationId || null,
  loyalty_choice: !isLoggedIn
  ? null
  : hasAutoLoyaltyDiscount
  ? "use_8"
  : canUseLoyalty4 && loyaltyChoice === "use_4"
  ? "use_4"
  : "keep",

loyalty_stickers_before:
  isLoggedIn && typeof loyaltyStickers === "number" ? loyaltyStickers : null,
  // NOWE: zapisujemy godzinę również dla "Na wynos"
  client_delivery_time,
};

      if (selectedOption === "delivery") {
  orderPayload.street = street || null;
  orderPayload.postal_code = postalCode || null;
  orderPayload.city = city || null;
  orderPayload.flat_number = flatNumber || null;
  if (custCoords) {
    orderPayload.delivery_lat = custCoords.lat;
    orderPayload.delivery_lng = custCoords.lng;
  }
} else if (selectedOption === "takeaway") {
  if (optionalAddress.trim()) {
    orderPayload.address = optionalAddress.trim();
  }
}

       const itemsPayload = items.map((item: any, index: number) => {
        const product = resolveProduct(item);

        // NOWE: zamiany w zestawie + dodatki per rolka
        const setSwaps = buildSetSwapsPayload(item, product);

        // tekst z notatki użytkownika + tekst z zamian
        const itemKey = getItemKey(item, index);
const userNote = notes[itemKey] || "";
        const swapsNote = buildSetSwapsNote(setSwaps);
        const combinedNote =
          userNote && swapsNote
            ? `${userNote} | ${swapsNote}`
            : userNote || swapsNote || "";

        return {
          product_id: product?.id ?? item.product_id ?? item.id ?? null,
          name: item.name,
          quantity: item.quantity || 1,
          unit_price: item.price,
          options: {
            addons: item.addons,
            swaps: item.swaps,
            set_swaps: setSwaps.length ? setSwaps : undefined, // struktura do panelu
            note: combinedNote, // to pole czyta backend (opt.note)
            restaurant: slug,
          },
        };
      });

     const tsToken = getTurnstileToken();

await safeFetch(`/api/orders/create?restaurant=${encodeURIComponent(slug)}`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "cf-turnstile-response": tsToken || "",
    "x-restaurant-slug": slug,
  },
  body: JSON.stringify({
    orderPayload,
    itemsPayload,
    restaurant: slug,
  }),
});

// UWAGA: koszyk czyścimy dopiero przy zamknięciu ekranu „Dziękujemy”,
// bo clearCart() w store często zamyka modal i nie widać podziękowania.
setOrderSent(true);

    } catch (err: any) {
  // jeśli backend zwróci 409 + TURNSTILE_RETRY (timeout-or-duplicate)
  if (err?.status === 409 || err?.code === "TURNSTILE_RETRY") {
    setErrorMessage("Weryfikacja wygasła lub została użyta ponownie. Zweryfikuj się jeszcze raz i spróbuj.");
    resetTurnstile();
    return;
  }

  setErrorMessage(err?.message || "Wystąpił błąd podczas składania zamówienia.");
  resetTurnstile();
} finally {
  setSubmitting(false);

  // krytyczne: nie pozwól na ponowne wysłanie tego samego tokenu
  // (na sukcesie też OK, ale możesz zamiast tego removeTurnstile() przy orderSent)
  if (!orderSent) resetTurnstile();
}
  };

 if (!isClient || !isCheckoutOpen) return null;

const OPTIONS: { key: OrderOption; label: string; Icon: any }[] = [
  { key: "takeaway", label: "Na wynos", Icon: ShoppingBag },
  { key: "delivery", label: "Dostawa", Icon: Truck },
];

const LegalConsent = (
  <label className="flex items-start gap-2 text-xs leading-5 text-black">
    <input
      type="checkbox"
      checked={legalAccepted}
      onChange={(e) => setLegalAccepted(e.target.checked)}
      className="mt-0.5"
    />
    <span>
      Akceptuję{" "}
      <a
        href="/legal/regulamin"
        target="_blank"
        rel="noopener noreferrer"
        className="underline text-[#de1d13] visited:text-[#de1d13] hover:opacity-80"
      >
        Regulamin
      </a>{" "}
      oraz{" "}
      <a
        href="/legal/polityka-prywatnosci"
        target="_blank"
        rel="noopener noreferrer"
        className="underline text-[#de1d13] visited:text-[#de1d13] hover:opacity-80"
      >
        Politykę prywatności
      </a>{" "}
      (v{TERMS_VERSION}).
    </span>
  </label>
);

/* ================= START: SHARED PRICE SUMMARY ================= */

const pln = (v: number) =>
  `${Number(v || 0).toFixed(2).replace(".", ",")} zł`;

const PriceSummaryCard = (
  <div className="rounded-2xl border border-black/10 bg-white p-4 space-y-4">
    <div className="flex items-center justify-between gap-3">
      <h4 className="text-sm font-semibold">Podsumowanie cen</h4>
      {selectedOption === "delivery" && deliveryInfo?.eta ? (
        <span className="text-[11px] text-black/60">
          ETA: {deliveryInfo.eta}
        </span>
      ) : null}
    </div>

    <div className="space-y-2 text-sm">
      <div className="flex items-center justify-between">
        <span className="text-black/70">Produkty</span>
        <span className="font-semibold">{pln(baseTotal)}</span>
      </div>

      {selectedOption ? (
        <div className="flex items-center justify-between">
          <span className="text-black/70">Opakowanie</span>
          <span className="font-semibold">{pln(packagingCost)}</span>
        </div>
      ) : null}

      {selectedOption === "delivery" ? (
        <div className="flex items-center justify-between">
          <span className="text-black/70">Dostawa</span>
          <span className="font-semibold">{pln(deliveryCost)}</span>
        </div>
      ) : null}

      {discount > 0 ? (
        <div className="flex items-center justify-between">
          <span className="text-black/70">Rabat</span>
          <span className="font-semibold text-green-700">
            -{pln(discount)}
          </span>
        </div>
      ) : null}

      <div className="h-px bg-black/10 my-2" />

      <div className="flex items-center justify-between text-base">
        <span className="font-semibold">Do zapłaty</span>
        <span className="font-bold">{pln(totalWithDelivery)}</span>
      </div>
    </div>

    <PromoSection
      promo={promo}
      promoError={promoError}
      onApply={applyPromo}
      onClear={clearPromo}
    />

    <div className="text-[11px] text-black/60">
      Ceny zawierają VAT.{" "}
      {selectedOption === "delivery"
        ? "Płatność: gotówka u kierowcy."
        : "Płatność: gotówka przy odbiorze."}
    </div>
  </div>
);

/* ================== END: SHARED PRICE SUMMARY ================== */


return (
  <>
    {TURNSTILE_SITE_KEY && (
      <Script
        id="cf-turnstile"
        src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit"
        async
        defer
        strategy="afterInteractive"
        onLoad={() => setTsReady(true)}
      />
    )}

    <div
  className="fixed inset-0 z-[58] bg-black/70 grid place-items-stretch lg:place-items-center p-0 lg:p-4 overflow-hidden"
  role="dialog"
  aria-modal="true"
  onMouseDown={(e) => {
    if (e.target === e.currentTarget) closeCheckoutModal();
  }}
>
        <div
  className="w-full max-w-5xl bg-white text-black shadow-2xl grid grid-rows-[auto,1fr] h-screen h-[100dvh] lg:h-auto lg:max-h-[90vh]"
  onMouseDown={(e) => e.stopPropagation()}
>
        <div className="flex items-center justify-between gap-3 px-4 py-3 sm:px-6 sm:py-4 border-b border-black/10 min-w-0">
  <h2 className="text-base sm:text-xl font-semibold min-w-0 truncate">
            Zamówienie — {restaurantCityLabel}
          </h2>
          {!orderSent && (
            <button
              aria-label="Zamknij"
              onClick={closeCheckoutModal}
              className="p-2 rounded-full hover:bg-black/5"
            >
              <X size={20} />
            </button>
          )}
        </div>

        <div className="min-h-0 overflow-y-auto overscroll-contain modal-scroll">
          <div
            className={clsx(
              // ZMIANA TUTAJ: dodane 'pb-32 lg:pb-6' zamiast samego p-6 (które ma domyślny padding zewsząd)
              "grid grid-cols-1 gap-6 px-6 pt-6 pb-24 lg:pb-6",
              !orderSent && "lg:grid-cols-[1fr_380px]"
            )}
          >       <div>
              {orderSent ? (
                <div className="min-h-[320px] flex flex-col items-center justify-center text-center space-y-5 px-4">
                  <div className="bg-white p-4 rounded-2xl shadow flex flex-col items-center gap-2">
                    <div className="bg-white p-3 rounded-xl">
                      <QRCode value={thanksQrUrl} size={170} />
                    </div>
                    <p className="text-xs text-black/60 max-w-xs">
                      Zeskanuj kod lub kliknij poniższy przycisk, aby ocenić
                      lokal w Google.
                    </p>
                  </div>
                  {!orderSent && (
  <div className="hidden lg:block">
    <div className="lg:sticky lg:top-6 space-y-4">
      {PriceSummaryCard}
    </div>
  </div>
)}

                  <h3 className="text-2xl font-bold">
                    Dziękujemy za zamówienie!
                  </h3>
                  <p className="text-black/70">
                    Potwierdzenie i link do śledzenia wysłaliśmy na Twój adres
                    e-mail.
                  </p>
                  <div className="flex justify-center gap-3 flex-wrap">
                    <button
                      onClick={() => window.open(thanksQrUrl, "_blank")}
                      className={`px-4 py-2 rounded-xl ${accentBtn}`}
                    >
                      Zostaw opinię w Google
                    </button>
                    <button
                      onClick={closeCheckoutModal}
                      className="px-4 py-2 rounded-xl border border-black/15"
                    >
                      Zamknij
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {errorMessage && (
                    <div className="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-2 text-red-700">
                      {errorMessage}
                    </div>
                  )}

                  {/* KROK 1 MOBILE: lista produktów */}
                  {checkoutStep === 1 && (
                    <div className="space-y-6">
                      <h3 className="text-2xl font-bold">Wybrane produkty</h3>

                      {/* START: lista pozycji koszyka */}
<div className="space-y-3 max-h-[360px] overflow-y-auto">
  {items.map((item: any, idx: number) => {
    // Stabilny key: preferuj unikalne ID pozycji koszyka, a jak nie ma – kompozyt
   const itemKey = getItemKey(item, idx);
    return (
      <div key={itemKey} className="space-y-1">
        <ProductItem
          prod={item}
          productCategory={productCategory}
          productsDb={productsDb}
          optionsByCat={optionsByCat}
          restaurantSlug={restaurantSlug}
          helpers={productHelpers}
          dbOptionsByProductId={dbOptionsByProductId}
        />

        <textarea
          className="w-full text-xs border border-black/15 rounded-xl px-2 py-1 bg-white"
          placeholder="Notatka do produktu (np. alergie, zamiany składników)"
          value={notes[itemKey] ?? ""}
          onChange={(e) =>
            setNotes((prev) => ({ ...prev, [itemKey]: e.target.value }))
          }
        />
      </div>
    );
  })}

  {items.length === 0 && (
    <p className="text-center text-black/60">Brak produktów w koszyku.</p>
  )}
</div>

                      <div className="-mx-6 sticky bottom-0 z-30 mt-4 border-t border-black/10 bg-white/95 backdrop-blur px-6 pt-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
  <div className="flex items-center gap-3">
    <div className="shrink-0">
      <ChopsticksControl value={chopsticksQty} onChange={setChopsticksQty} />
    </div>

    <button
      onClick={nextStep}
      disabled={items.length === 0}
      className={`ml-auto min-w-[160px] py-2 rounded-xl font-semibold ${accentBtn} disabled:opacity-50`}
    >
      Dalej →
    </button>
  </div>
</div>
                    </div>
                  )}

                  {/* KROK 1 DESKTOP / KROK 2 MOBILE: sposób odbioru */}
                  {/* KROK 2: sposób odbioru */}
{checkoutStep === 2 && (
                    <div className="space-y-6">
                      <h3 className="text-2xl font-bold">Sposób odbioru</h3>

                      <div className="grid grid-cols-2 gap-3">
                        {OPTIONS.map(({ key, label, Icon }) => (
                          <button
                            key={key}
                            onClick={() => handleSelectOption(key)}
                            className={clsx(
                              "flex flex-col items-center justify-center border px-3 py-4 transition",
                              selectedOption === key
                                ? "bg-yellow-400 text-black border-yellow-500"
                                : "bg-gray-50 text-black border-black/10 hover:bg-gray-100"
                            )}
                          >
                            <Icon size={22} />
                            <span className="mt-1 text-sm font-medium">
                              {label}
                            </span>
                          </button>
                        ))}
                      </div>

                      {selectedOption === "delivery" && (
                        <div className="rounded-xl bg-yellow-50 border border-yellow-200 p-3 text-sm">
                          Płatność: <b>gotówka u kierowcy</b>.
                        </div>
                      )}

                     {selectedOption && (
  <div className="space-y-2">
    <h4 className="font-semibold">
      {selectedOption === "delivery" ? "Czas dostawy" : "Czas odbioru"}
    </h4>
    <div className="flex flex-wrap gap-6 items-center">
      <label className="flex items-center gap-2">
        <input
          type="radio"
          name="timeOption"
          value="asap"
          checked={deliveryTimeOption === "asap"}
          onChange={() => setDeliveryTimeOption("asap")}
        />
        <span>Jak najszybciej</span>
      </label>
       <label className="flex items-center gap-2">
        <input
          type="radio"
          name="timeOption"
          value="schedule"
          checked={deliveryTimeOption === "schedule"}
          disabled={!canSchedule}
          onChange={() => {
            if (!canSchedule) return;
            setDeliveryTimeOption("schedule");
          }}
        />
        <span>
          Na godzinę{!canSchedule ? " (brak wolnych slotów)" : ""}
        </span>
      </label>

      {deliveryTimeOption === "schedule" && canSchedule && (
        <select
          className="border border-black/15 rounded-xl px-2 py-1 bg-white"
          value={scheduledTime}
          onChange={(e) => setScheduledTime(e.target.value)}
        >
          {scheduleSlots.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      )}

      {deliveryTimeOption === "schedule" && !canSchedule && (
        <span className="text-xs text-red-600">
          Brak dostępnych godzin na dziś — wybierz „Jak najszybciej”.
        </span>
      )}
    </div>
    <p className="text-xs text-black/60">
      Dzisiejsze godziny w {restaurantCityLabel}: {openInfo.label}
    </p>
  </div>
)}

                      <div className="-mx-6 sticky bottom-0 z-30 mt-4 border-t border-black/10 bg-white/95 backdrop-blur px-6 pt-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
  <div className="flex items-center gap-3">
    <button
      type="button"
      onClick={() => goToStep(1)}
      className="px-4 py-2 rounded-xl border border-black/15"
    >
      ← Cofnij
    </button>

    <div className="flex-1 flex justify-center">
      <ChopsticksControl value={chopsticksQty} onChange={setChopsticksQty} />
    </div>

    <button
      onClick={nextStep}
      disabled={!selectedOption}
      className={`min-w-[220px] py-2 rounded-xl font-semibold ${accentBtn} disabled:opacity-50`}
    >
      Dalej →
    </button>
  </div>
</div>



                    </div>
                  )}

                  {/* KROK 3: dane kontaktowe (mobile + desktop), a podsumowanie tylko mobile */}
{checkoutStep === 3 && (
  <div className="space-y-6">
    <h3 className="text-2xl font-bold">Dane kontaktowe</h3>

    {selectedOption === "delivery" && (
      <>
        <AddressAutocomplete
          onAddressSelect={onAddressSelect}
          setCity={setCity}
          setPostalCode={setPostalCode}
          setFlatNumber={setFlatNumber}
        />

        <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-black/70">
          <span>Nie możesz znaleźć swojego adresu?</span>
          {restaurantPhone && (
            <a
              href={`tel:${restaurantPhone.replace(/\s+/g, "")}`}
              className="inline-flex items-center justify-center rounded-full border border-black/15 px-3 py-1 font-semibold hover:bg-gray-100 text-black"
            >
              Zadzwoń do nas
            </a>
          )}
        </div>

        <p className="text-xs text-black/60">
          Najpierw wybierz adres z listy Google – dopiero wtedy pola poniżej odblokują się do edycji.
        </p>

        <div className="grid grid-cols-1 gap-2">
          <input
            type="text"
            placeholder="Adres (ulica i numer domu)"
            className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white disabled:bg-gray-100 disabled:text-black/50 disabled:cursor-not-allowed"
            value={street}
            onChange={(e) => setStreet(e.target.value)}
            disabled={requireAutocomplete && !custCoords}
          />
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Numer mieszkania (opcjonalnie)"
              className="flex-1 px-3 py-2 border border-black/15 rounded-xl bg-white disabled:bg-gray-100 disabled:text-black/50 disabled:cursor-not-allowed"
              value={flatNumber}
              onChange={(e) => setFlatNumber(e.target.value)}
              disabled={requireAutocomplete && !custCoords}
            />
            <input
              type="text"
              placeholder="Kod pocztowy"
              className="flex-1 px-3 py-2 border border-black/15 rounded-xl bg-white disabled:bg-gray-100 disabled:text-black/50 disabled:cursor-not-allowed"
              value={postalCode}
              onChange={(e) => setPostalCode(e.target.value)}
              disabled={requireAutocomplete && !custCoords}
            />
          </div>
          <input
            type="text"
            placeholder="Miasto"
            className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white disabled:bg-gray-100 disabled:text-black/50 disabled:cursor-not-allowed"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            disabled={requireAutocomplete && !custCoords}
          />
          {requireAutocomplete && !custCoords && (
            <p className="text-xs text-red-600">
              Wpisanie adresu ręcznie jest zablokowane – wybierz pozycję z listy podpowiedzi Google.
            </p>
          )}
        </div>
      </>
    )}

    {selectedOption === "takeaway" && (
      <div className="rounded-xl bg-gray-50 border border-black/10 p-3 text-sm">
        Odbiór osobisty w lokalu. Płatność przy odbiorze gotówką.
      </div>
    )}

    <div className="grid grid-cols-1 gap-2">
      <input
        type="text"
        placeholder="Imię"
        className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        type="tel"
        placeholder="Telefon"
        className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white"
        value={phone}
        onChange={(e) => setPhone(e.target.value)}
      />
      {selectedOption === "takeaway" && (
        <input
          type="text"
          placeholder="Uwagi do odbioru (opcjonalnie)"
          className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white"
          value={optionalAddress}
          onChange={(e) => setOptionalAddress(e.target.value)}
        />
      )}
      <input
        type="email"
        placeholder="Email (wymagany do potwierdzenia)"
        className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white"
        value={contactEmail}
        onChange={(e) => setContactEmail(e.target.value)}
      />
      {contactEmail !== "" && !validEmail && (
        <p className="text-xs text-red-600">Podaj poprawny adres e-mail.</p>
      )}
    </div>

    <div className="-mx-6 sticky bottom-0 z-30 mt-4 border-t border-black/10 bg-white/95 backdrop-blur px-6 pt-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
  <div className="flex items-center gap-3">
    <button
      onClick={() => goToStep(2)}
      className="px-4 py-2 rounded-xl border border-black/15"
    >
      ← Cofnij
    </button>

    <div className="flex-1 flex justify-center">
      <ChopsticksControl value={chopsticksQty} onChange={setChopsticksQty} />
    </div>

    <button
      onClick={goNextFromStep3}
      disabled={
        !name ||
        !phone ||
        !validEmail ||
        (selectedOption === "delivery" &&
          (!street || !postalCode || !city || (requireAutocomplete && !custCoords)))
      }
      className={`min-w-[220px] py-2 rounded-xl text-white font-semibold ${accentBtn} disabled:opacity-50`}
    >
      Dalej →
    </button>
  </div>
</div>


                      {/* MOBILE: podsumowanie + zgody + Turnstile */}
                      {isMobile && (
  <div ref={mobileSummaryRef} className="mt-3 space-y-4 scroll-mt-6">
                          {/* Podsumowanie cen */}
                          <div className="rounded-2xl border border-black/10 bg-white p-4 space-y-2">
                            <h4 className="text-lg font-semibold">Podsumowanie</h4>

<p className="text-[11px] text-black/60">
  {selectedOption === "delivery"
    ? "Sposób: dostawa"
    : selectedOption === "takeaway"
    ? "Sposób: odbiór osobisty"
    : "Sposób: —"}
</p>

{/* Lista pozycji (żeby było widać co wybrane) */}
<div className="space-y-2 max-h-[180px] overflow-y-auto border-y border-black/10 py-2">
  {items.length === 0 ? (
    <p className="text-sm text-black/60 text-center">Brak produktów.</p>
  ) : (
    items.map((it: any, i: number) => {
      const label = withCategoryPrefix(it.name, productCategory(it.name));
      const qty = it.quantity || 1;
      return (
        <div key={i} className="flex justify-between text-sm">
          <span className="truncate pr-2">
            {label} ×{qty}
          </span>
          <span>{getItemLineTotal(it).toFixed(2)} zł</span>
        </div>
      );
    })
  )}
</div>

<div className="space-y-1 text-sm">
  <div className="flex justify-between">
    <span>Produkty:</span>
    <span>{baseTotal.toFixed(2)} zł</span>
  </div>

  {selectedOption && (
    <div className="flex justify-between">
      <span>Opakowanie:</span>
      <span>{packagingUnit.toFixed(2)} zł</span>
    </div>
  )}

  {/* Dostawa: pokazuj zawsze przy delivery (fallback gdy jeszcze nie policzona) */}
  {selectedOption === "delivery" && (
    <div className="flex justify-between">
      <span>Dostawa:</span>
      <span>
        {deliveryInfo && typeof deliveryInfo.cost === "number"
          ? `${deliveryInfo.cost.toFixed(2)} zł`
          : "—"}
      </span>
    </div>
  )}
                            </div>

                            {/* LOYALTY – MOBILE */}
                            {isLoggedIn && (
                              <div className="mt-2">
                                {loyaltyLoading ? (
                                  <p className="text-[11px] text-black/60">
                                    Sprawdzamy Twoje naklejki...
                                  </p>
                                ) : (
                                  typeof loyaltyStickers === "number" && (
                                    <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs space-y-2">
                                      <div>
                                        Masz{" "}
                                        <b>{loyaltyStickers}</b> naklejek w
                                        programie lojalnościowym.
                                      </div>

                                      {canUseLoyalty4 && (
                                        <div className="space-y-1">
                                          <div className="font-semibold text-sm">
                                            Czy chcesz wymienić 4 naklejki na
                                            darmową rolkę?
                                          </div>
                                          <label className="flex items-center gap-2">
                                            <input
                                              type="radio"
                                              name="loyalty_choice_mobile"
                                              value="use_4"
                                              checked={
                                                loyaltyChoice === "use_4"
                                              }
                                              onChange={() =>
                                                setLoyaltyChoice("use_4")
                                              }
                                            />
                                            <span>
                                              Tak, wykorzystaj 4 naklejki w tym
                                              zamówieniu.
                                            </span>
                                          </label>
                                          <label className="flex items-center gap-2">
                                            <input
                                              type="radio"
                                              name="loyalty_choice_mobile"
                                              value="keep"
                                              checked={
                                                loyaltyChoice === "keep"
                                              }
                                              onChange={() =>
                                                setLoyaltyChoice("keep")
                                              }
                                            />
                                            <span>
                                              Nie teraz, zbieram dalej.
                                            </span>
                                          </label>
                                        </div>
                                      )}

                                      {!canUseLoyalty4 &&
                                        hasAutoLoyaltyDiscount && (
                                          <div className="font-semibold text-sm">
                                            Masz już co najmniej 8 naklejek –
                                            rabat lojalnościowy doliczymy przy
                                            realizacji zamówienia.
                                          </div>
                                        )}
                                    </div>
                                  )
                                )}
                              </div>
                            )}

                            <PromoSection
                              promo={promo}
                              promoError={promoError}
                              onApply={applyPromo}
                              onClear={clearPromo}
                            />

                            {discount > 0 && (
                              <div className="flex justify-between text-sm text-green-700">
                                <span>Rabat:</span>
                                <span>-{discount.toFixed(2)} zł</span>
                              </div>
                            )}

                            <div className="flex justify-between font-semibold border-t border-black/10 pt-2">
                              <span>RAZEM:</span>
                              <span>
                                {totalWithDelivery.toFixed(2)} zł
                              </span>
                            </div>

                            {selectedOption === "delivery" && (
  <p className="text-[11px] text-black/60 text-center mt-1">
    {deliveryInfo?.eta ? `ETA: ${deliveryInfo.eta}` : "ETA: wybierz adres, aby policzyć dostawę"}
  </p>
)}
                          </div>

                          {/* Potwierdzenia + Turnstile */}
                          <div className="rounded-2xl border border-black/10 bg-gray-50 p-4 space-y-3">
                            <h4 className="text-lg font-semibold">
                              Potwierdzenia
                            </h4>
                            <div className="space-y-3">
                              {LegalConsent}
                              <label className="flex items-start gap-2 text-xs leading-5 text-black">
                                <input
                                  type="checkbox"
                                  checked={confirmCityOk}
                                  onChange={(e) =>
                                    setConfirmCityOk(e.target.checked)
                                  }
                                  className="mt-0.5"
                                />
                                <span>
                                  Uwaga: składasz zamówienie do restauracji w{" "}
                                  <b>{restaurantCityLabel}</b>. Potwierdzam, że
                                  to prawidłowe miasto.
                                </span>
                              </label>

                              {TURNSTILE_SITE_KEY ? (
                                <div>
                                  <h4 className="font-semibold mb-1">
                                    Weryfikacja
                                  </h4>
                                  {turnstileError ? (
                                    <p className="text-sm text-red-600">
                                      Nie udało się załadować weryfikacji.
                                    </p>
                                  ) : (
                                    <>
                                      <div ref={tsMobileRef} />
                                      <p className="text-[11px] text-black/60 mt-1">
                                        Chronimy formularz przed botami.
                                      </p>
                                    </>
                                  )}
                                </div>
                              ) : (
                                <p className="text-[11px] text-black/60">
                                  Weryfikacja Turnstile wyłączona (brak
                                  klucza).
                                </p>
                              )}
                            </div>

                            {!shouldHideOrderActions && (
                              <button
                                onClick={handleSubmitOrder}
                                disabled={
                                  submitting ||
                                  !legalAccepted ||
                                  !confirmCityOk ||
                                  (TURNSTILE_SITE_KEY
                                    ? !turnstileToken
                                    : false)
                                }
                                className={`w-full mt-2 py-2 rounded-xl font-semibold ${accentBtn} disabled:opacity-50`}
                              >
                                {submitting ? (
                                  <span className="flex items-center justify-center gap-2">
                                    <span className="h-4 w-4 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                                    Przetwarzanie...
                                  </span>
                                ) : (
                                  "✅ Zamawiam"
                                )}
                              </button>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* KROK 4 DESKTOP: podsumowanie + pałeczki */}
{!isMobile && checkoutStep === 4 && (
  <div className="space-y-6">
    <h3 className="text-2xl font-bold text-center">
      Podsumowanie i finalizacja
    </h3>

    {selectedOption === "delivery" && (
      <div className="rounded-xl bg-yellow-50 border border-yellow-200 p-3 text-sm text-center">
        <b>Płatność wyłącznie gotówką u kierowcy.</b>
      </div>
    )}

    {PriceSummaryCard}

    <div className="rounded-2xl border border-black/10 bg-gray-50 p-4 space-y-3">
      <h4 className="text-lg font-semibold">Potwierdzenia</h4>

      <div className="space-y-3">
        {LegalConsent}

        <label className="flex items-start gap-2 text-xs leading-5 text-black">
          <input
            type="checkbox"
            checked={confirmCityOk}
            onChange={(e) => setConfirmCityOk(e.target.checked)}
            className="mt-0.5"
          />
          <span>
            Uwaga: składasz zamówienie do restauracji w{" "}
            <b>{restaurantCityLabel}</b>. Potwierdzam, że to prawidłowe miasto.
          </span>
        </label>

        <p className="text-[11px] text-black/60 text-center">
          Dzisiejsze godziny w {restaurantCityLabel}: {openInfo.label}
        </p>

        {TURNSTILE_SITE_KEY ? (
          <div className="mt-1">
            <h4 className="font-semibold mb-1">Weryfikacja</h4>
            {turnstileError ? (
              <p className="text-sm text-red-600">
                Nie udało się załadować weryfikacji.
              </p>
            ) : (
              <>
                <div ref={tsDesktopRef} />
                <p className="text-[11px] text-black/60 mt-1">
                  Chronimy formularz przed botami.
                </p>
              </>
            )}
          </div>
        ) : (
          <p className="text-[11px] text-black/60">
            Weryfikacja Turnstile wyłączona (brak klucza).
          </p>
        )}
      </div>
    </div>

    <div className="-mx-6 sticky bottom-0 z-30 mt-4 border-t border-black/10 bg-white/95 backdrop-blur px-6 pt-4 pb-4">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => goToStep(3)}
          className="px-4 py-2 rounded-xl border border-black/15"
        >
          ← Cofnij
        </button>

        <div className="flex-1 flex justify-center">
          <ChopsticksControl value={chopsticksQty} onChange={setChopsticksQty} />
        </div>

        {!shouldHideOrderActions && (
          <button
            onClick={handleSubmitOrder}
            disabled={
              submitting ||
              !legalAccepted ||
              !confirmCityOk ||
              (TURNSTILE_SITE_KEY ? !turnstileToken : false)
            }
            className={`min-w-[220px] py-2 rounded-xl font-semibold ${accentBtn} disabled:opacity-50`}
          >
            {submitting ? (
              <span className="flex items-center justify-center gap-2">
                <span className="h-4 w-4 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                Przetwarzanie...
              </span>
            ) : (
              "✅ Zamawiam"
            )}
          </button>
        )}
      </div>
    </div>
  </div>
)}

                </>
              )}
            </div>

            {/* PASEK BOCZNY PODSUMOWANIA (DESKTOP) */}
            {!orderSent && checkoutStep !== 4 && (
  <aside className="hidden lg:flex">
                <div className="sticky top-4 w-[340px] mx-auto border border-black/10 bg-white p-5 shadow-xl text-black space-y-4 text-left">
                  <h4 className="text-xl font-bold text-center">
                    Podsumowanie
                  </h4>

                  <div className="space-y-2 max-h-[200px] overflow-y-auto">
                    {items.length === 0 ? (
                      <p className="text-sm text-black/60 text-center">
                        Brak produktów.
                      </p>
                    ) : (
                      items.map((it: any, i: number) => {
                        const label = withCategoryPrefix(
                          it.name,
                          productCategory(it.name)
                        );
                        return (
                          <div
                            key={i}
                            className="flex justify-between text-sm"
                          >
                            <span className="truncate pr-2">
                              {label} ×{it.quantity || 1}
                            </span>
                            <span>
                              {getItemLineTotal(it).toFixed(2)} zł
                            </span>
                          </div>
                        );
                      })
                    )}
                  </div>

                  <div className="flex justify-between">
                    <span>Produkty:</span>
                    <span>{baseTotal.toFixed(2)} zł</span>
                  </div>
                  {selectedOption && (
                    <div className="flex justify-between">
                      <span>Opakowanie:</span>
                      <span>{packagingUnit.toFixed(2)} zł</span>
                    </div>
                  )}
                  {deliveryInfo && (
                    <div className="flex justify-between">
                      <span>Dostawa:</span>
                      <span>{deliveryInfo.cost.toFixed(2)} zł</span>
                    </div>
                  )}

                  {/* LOYALTY – DESKTOP */}
                  {isLoggedIn && (
                    <div className="mt-2">
                      {loyaltyLoading ? (
                        <p className="text-[11px] text-black/60 text-center">
                          Sprawdzamy Twoje naklejki...
                        </p>
                      ) : (
                        typeof loyaltyStickers === "number" && (
                          <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs space-y-2">
                            <div className="text-center">
                              Masz <b>{loyaltyStickers}</b> naklejek w
                              programie lojalnościowym.
                            </div>

                            {canUseLoyalty4 && (
                              <div className="space-y-1">
                                <div className="font-semibold text-sm text-center">
                                  Czy chcesz wymienić 4 naklejki na darmową
                                  rolkę?
                                </div>
                                <label className="flex items-center gap-2">
                                  <input
                                    type="radio"
                                    name="loyalty_choice_desktop"
                                    value="use_4"
                                    checked={loyaltyChoice === "use_4"}
                                    onChange={() =>
                                      setLoyaltyChoice("use_4")
                                    }
                                  />
                                  <span>
                                    Tak, wykorzystaj 4 naklejki w tym
                                    zamówieniu.
                                  </span>
                                </label>
                                <label className="flex items-center gap-2">
                                  <input
                                    type="radio"
                                    name="loyalty_choice_desktop"
                                    value="keep"
                                    checked={loyaltyChoice === "keep"}
                                    onChange={() =>
                                      setLoyaltyChoice("keep")
                                    }
                                  />
                                  <span>Nie teraz, zbieram dalej.</span>
                                </label>
                              </div>
                            )}

                            {!canUseLoyalty4 && hasAutoLoyaltyDiscount && (
                              <div className="font-semibold text-sm text-center">
                                Masz już co najmniej 8 naklejek – rabat
                                lojalnościowy doliczymy przy realizacji
                                zamówienia.
                              </div>
                            )}
                          </div>
                        )
                      )}
                    </div>
                  )}

                  <PromoSection
                    promo={promo}
                    promoError={promoError}
                    onApply={applyPromo}
                    onClear={clearPromo}
                  />

                  {discount > 0 && (
                    <div className="flex justify-between text-green-700">
                      <span>Rabat:</span>
                      <span>-{discount.toFixed(2)} zł</span>
                    </div>
                  )}
                  <div className="flex justify-between font-semibold border-t pt-2">
                    <span>RAZEM:</span>
                    <span>{totalWithDelivery.toFixed(2)} zł</span>
                  </div>
                  {deliveryInfo && (
                    <p className="text-xs text-black/60 text-center">
                      ETA: {deliveryInfo.eta}
                    </p>
                  )}

                  <div className="space-y-2">
                    {LegalConsent}
                    <label className="flex items-start gap-2 text-xs leading-5 text-black">
                      <input
                        type="checkbox"
                        checked={confirmCityOk}
                        onChange={(e) =>
                          setConfirmCityOk(e.target.checked)
                        }
                        className="mt-0.5"
                      />
                      <span>
                        Uwaga: składasz zamówienie do restauracji w{" "}
                        <b>{restaurantCityLabel}</b>. Potwierdzam, że to
                        prawidłowe miasto.
                      </span>
                    </label>

                    <p className="text-[11px] text-black/60 text-center">
                      Dzisiejsze godziny w {restaurantCityLabel}:{" "}
                      {openInfo.label}
                    </p>

                    {TURNSTILE_SITE_KEY ? (
                      <div className="mt-1">
                        <h4 className="font-semibold mb-1">
                          Weryfikacja
                        </h4>
                        {turnstileError ? (
                          <p className="text-sm text-red-600">
                            Nie udało się załadować weryfikacji.
                          </p>
                        ) : (
                          <>
                            <div ref={tsDesktopRef} />
                            <p className="text-[11px] text-black/60 mt-1">
                              Chronimy formularz przed botami.
                            </p>
                          </>
                        )}
                      </div>
                    ) : (
                      <p className="text-[11px] text-black/60">
                        Weryfikacja Turnstile wyłączona (brak klucza).
                      </p>
                    )}

                    {!shouldHideOrderActions && (
                      <button
                        onClick={handleSubmitOrder}
                        disabled={
                          submitting ||
                          !legalAccepted ||
                          !confirmCityOk ||
                          (TURNSTILE_SITE_KEY
                            ? !turnstileToken
                            : false)
                        }
                        className={`w-full mt-2 py-2 rounded-xl font-semibold ${accentBtn} disabled:opacity-50`}
                      >
                        {submitting ? (
                          <span className="flex items-center justify-center gap-2">
                            <span className="h-4 w-4 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                            Przetwarzanie...
                          </span>
                        ) : (
                          "✅ Zamawiam"
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </aside>
            )}
          </div>
        </div>
      </div>
    </div>
  </>
);
}