"use client";

import { useState, useMemo } from "react";
import { Tab } from "@headlessui/react";
import { IconCalendarEvent, IconMap, IconBrandGoogle } from "@tabler/icons-react";

import TableLayoutForm from "@/components/admin/settings/TableLayoutForm";
import DeliveryZonesForm from "@/components/admin/settings/DeliveryZonesForm";
import IntegrationsForm from "@/components/admin/settings/IntegrationsForm";

const tabs = [
  { key: "tables", label: "Rezerwacje & Stoły", icon: IconCalendarEvent, component: <TableLayoutForm /> },
  { key: "delivery", label: "Strefy dostawy", icon: IconMap, component: <DeliveryZonesForm /> },
  { key: "integr", label: "Integracje", icon: IconBrandGoogle, component: <IntegrationsForm /> },
];

function cx(...c: (string | false | null | undefined)[]) { return c.filter(Boolean).join(" "); }

export default function SettingsPage() {
  const [selectedTab, setSelectedTab] = useState(0);
  const current = useMemo(() => tabs[selectedTab], [selectedTab]);

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="mx-auto max-w-6xl space-y-4">
        {/* nagłówek jak w AdminPanel */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Ustawienia panelu</h1>
            <p className="text-sm text-slate-600">Konfiguracja dla aktualnie wybranego lokalu.</p>
          </div>
        </div>

        {/* selector mobilny */}
        <div className="md:hidden">
          <label htmlFor="mobile-tab" className="sr-only">Wybierz sekcję</label>
          <div className="relative">
            <select
              id="mobile-tab"
              value={selectedTab}
              onChange={(e) => setSelectedTab(Number(e.target.value))}
              className="w-full appearance-none rounded-xl border border-slate-200 bg-white px-4 py-2 pr-8 shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-300"
            >
              {tabs.map((t, i) => <option key={t.key} value={i}>{t.label}</option>)}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-slate-600">▾</div>
          </div>
        </div>

        <Tab.Group selectedIndex={selectedTab} onChange={setSelectedTab}>
          {/* zakładki desktop jak chipy z AdminPanel */}
          <div className="hidden md:block">
            <Tab.List className="flex flex-wrap gap-2">
              {tabs.map((t) => (
                <Tab key={t.key}
                  className={({ selected }) => cx(
                    "flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold shadow-sm transition",
                    selected ? "bg-slate-900 text-white" : "bg-white text-slate-800 hover:bg-slate-100 border"
                  )}
                >
                  <t.icon size={16} />
                  {t.label}
                </Tab>
              ))}
            </Tab.List>
          </div>

          {/* karta z obramowaniem jak w AdminPanel */}
          <div className="mt-4">
            <div className="overflow-hidden rounded-2xl border bg-white shadow-sm">
              <div className="px-6 py-5 border-b md:hidden">
                <div className="flex items-center gap-3">
                  <current.icon className="h-5 w-5 text-slate-900" />
                  <h2 className="text-lg font-semibold text-slate-900">{current.label}</h2>
                </div>
              </div>
              <Tab.Panels className="p-6">
                {tabs.map((t) => (
                  <Tab.Panel key={t.key} className="space-y-6">
                    <div className="hidden items-center gap-3 md:flex">
                      <t.icon className="h-5 w-5 text-slate-900" />
                      <h2 className="text-xl font-semibold text-slate-900">{t.label}</h2>
                    </div>
                    <div>{t.component}</div>
                  </Tab.Panel>
                ))}
              </Tab.Panels>
            </div>
          </div>
        </Tab.Group>
      </div>
    </div>
  );
}
