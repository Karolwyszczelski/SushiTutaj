export const runtime = "nodejs";
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { cookies } from "next/headers";
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs";
import { z } from "zod";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  { auth: { persistSession: false } }
);

const blockedPatchSchema = z
  .object({
    pattern: z.string().min(1).max(500).optional(),
    note: z.string().max(500).nullable().optional(),
    active: z.boolean().optional(),
  })
  .refine((obj) => Object.keys(obj).length > 0, {
    message: "Brak pól do aktualizacji.",
  });

type BlockedPatch = z.infer<typeof blockedPatchSchema>;

async function requireAdminAndRestaurant() {
  const cookieStore = await cookies();
  const restaurantId = cookieStore.get("restaurant_id")?.value;

  if (!restaurantId) {
    return {
      error: NextResponse.json(
        { error: "Brak wybranego lokalu (cookie restaurant_id)." },
        { status: 400 }
      ),
    };
  }

  const routeClient = createRouteHandlerClient({ cookies });
  const {
    data: { session },
    error: sessionError,
  } = await routeClient.auth.getSession();

  if (sessionError || !session) {
    return {
      error: NextResponse.json({ error: "Brak sesji." }, { status: 401 }),
    };
  }

  const { data: membership, error: membershipError } = await supabaseAdmin
    .from("restaurant_admins")
    .select("restaurant_id, role")
    .eq("user_id", session.user.id)
    .eq("restaurant_id", restaurantId)
    .in("role", ["owner", "admin", "manager"])
    .maybeSingle();

  if (membershipError) {
    console.error("[blocked_addresses] membership error", membershipError);
    return {
      error: NextResponse.json(
        { error: "Błąd sprawdzania uprawnień." },
        { status: 500 }
      ),
    };
  }

  if (!membership) {
    return {
      error: NextResponse.json(
        { error: "Brak uprawnień do tego lokalu." },
        { status: 403 }
      ),
    };
  }

  return { restaurantId };
}

export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  const ctx = await requireAdminAndRestaurant();
  if ("error" in ctx) return ctx.error;
  const { restaurantId } = ctx;

  const id = params.id;
  if (!id) {
    return NextResponse.json({ error: "Brak ID wpisu." }, { status: 400 });
  }

  let payload: BlockedPatch;
  try {
    const body = await req.json();
    payload = blockedPatchSchema.parse({
      pattern:
        body.pattern === undefined
          ? undefined
          : String(body.pattern).trim().toLowerCase(),
      note:
        body.note === undefined
          ? undefined
          : body.note === null
          ? null
          : String(body.note),
      active:
        typeof body.active === "boolean" ? body.active : undefined,
    });
  } catch (e) {
    console.error("[blocked_addresses] invalid body (PATCH)", e);
    return NextResponse.json(
      { error: "Nieprawidłowe dane formularza." },
      { status: 400 }
    );
  }

  const { error } = await supabaseAdmin
    .from("blocked_addresses")
    .update(payload)
    .eq("id", id)
    .eq("restaurant_id", restaurantId);

  if (error) {
    console.error("[blocked_addresses] update error", error);
    return NextResponse.json(
      { error: "Błąd zapisu blokady w bazie." },
      { status: 500 }
    );
  }

  return NextResponse.json({ ok: true });
}

export async function DELETE(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const ctx = await requireAdminAndRestaurant();
  if ("error" in ctx) return ctx.error;
  const { restaurantId } = ctx;

  const id = params.id;
  if (!id) {
    return NextResponse.json({ error: "Brak ID wpisu." }, { status: 400 });
  }

  const { error } = await supabaseAdmin
    .from("blocked_addresses")
    .delete()
    .eq("id", id)
    .eq("restaurant_id", restaurantId);

  if (error) {
    console.error("[blocked_addresses] delete error", error);
    return NextResponse.json(
      { error: "Błąd usuwania blokady w bazie." },
      { status: 500 }
    );
  }

  return NextResponse.json({ ok: true });
}
