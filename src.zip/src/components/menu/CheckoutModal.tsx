"use client";


import React, {
  useState,
  useEffect,
  useMemo,
  useRef,
  useDeferredValue,
  useCallback,
} from "react";
import Script from "next/script";
import { X, ShoppingBag, Truck } from "lucide-react";
import clsx from "clsx";
import QRCode from "react-qr-code";
import { useSession } from "@supabase/auth-helpers-react";
import { createClient } from "@supabase/supabase-js";
import { toZonedTime } from "date-fns-tz";
import useIsClient from "@/lib/useIsClient";
import useCartStore from "@/store/cartStore";
import AddressAutocomplete from "@/components/menu/AddressAutocomplete";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";


/* ---------- ENV / const ---------- */
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);
declare global {
  interface Window {
    turnstile?: any;
  }
}

const TERMS_VERSION = process.env.NEXT_PUBLIC_TERMS_VERSION || "2025-09-15";
const TURNSTILE_SITE_KEY = process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY || "";
const THANKS_QR_URL =
  process.env.NEXT_PUBLIC_REVIEW_QR_URL || "https://g.co/kgs/47NSDMH";

/** QR do opinii Google per miasto (fallback: THANKS_QR_URL) */
const CITY_REVIEW_QR_URLS: Record<string, string> = {
  ciechanow: process.env.NEXT_PUBLIC_REVIEW_QR_CIECHANOW || THANKS_QR_URL,
  przasnysz: process.env.NEXT_PUBLIC_REVIEW_QR_PRZASNYSZ || THANKS_QR_URL,
  szczytno: process.env.NEXT_PUBLIC_REVIEW_QR_SZCZYTNO || THANKS_QR_URL,
  plonsk: process.env.NEXT_PUBLIC_REVIEW_QR_PLONSK || THANKS_QR_URL,
  mlawa: process.env.NEXT_PUBLIC_REVIEW_QR_MLAWA || THANKS_QR_URL,
  pultusk: process.env.NEXT_PUBLIC_REVIEW_QR_PULTUSK || THANKS_QR_URL,
};

/** Telefony do lokali – używane w sekcji "Nie możesz znaleźć swojego adresu?" */
const CITY_PHONE: Record<string, string> = {
  ciechanow: "+48 780 072 372",
  przasnysz: "+48 518 166 888",
  szczytno: "+48 510 700 995",
};

/** Zwraca numer telefonu dla aktualnego miasta (albo null, jeśli nie ma) */
function getRestaurantPhone(slug: string): string | null {
  const s = (slug || "").toLowerCase();
  return CITY_PHONE[s] || null;
}

/** WYMÓG: adres musi być wybrany z Autocomplete (posiadamy współrzędne) */
const REQUIRE_AUTOCOMPLETE = true;

type OrderOption = "takeaway" | "delivery";
type Zone = {
  id: string;
  min_distance_km: number;
  max_distance_km: number;
  min_order_value: number;
  cost: number;
  free_over: number | null;
  eta_min_minutes: number;
  eta_max_minutes: number;
  pricing_type?: "per_km" | "flat";
  active?: boolean;
};
type ProductDb = {
  id: string;
  name: string;
  subcategory: string | null;
  description: string | null;
  restaurant_id?: string | null;
};

/* —— RABATY —— */
type ApplyScope =
  | "all"
  | "include_categories"
  | "exclude_categories"
  | "include_products"
  | "exclude_products";

type DiscountCodeRow = {
  id: string;
  code: string | null;
  active: boolean | null;
  type: "percent" | "amount" | null;
  value: number | null;
  min_order: number | null;
  expires_at: string | null;
  restaurant_id: string | null;
  description?: string | null;
  require_code: boolean | null;
  apply_scope: ApplyScope | null;
  include_categories: string[] | null;
  exclude_categories: string[] | null;
  include_products: string[] | null;
  exclude_products: string[] | null;
};

type Promo =
  | {
      id: string;
      code: string | null;
      type: "percent" | "amount";
      value: number;
      apply_scope: ApplyScope;
      include_categories: string[] | null;
      exclude_categories: string[] | null;
      include_products: string[] | null;
      exclude_products: string[] | null;
      min_order: number | null;
      require_code: boolean;
    }
  | null;

  type LoyaltyChoice = "keep" | "use_4";

/* Sushi sosy i dodatki */
const BASE_SAUCES = [
  "Sos sojowy",
  "Teryiaki",
  "Spicy Mayo",
  "Mango",
  "Sriracha",
  "Żurawina",
];

// dodatkowe sosy do frytek z batatów (tylko Przasnysz / Szczytno)
const BATATA_SAUCES = ["Sos czekoladowy", "Sos toffi"];

// do wyceny – wszystkie sosy liczymy po 3 zł
const ALL_SAUCES = [...BASE_SAUCES, ...BATATA_SAUCES];

const EXTRAS = ["Tempura", "Płatek sojowy", "Tamago", "Ryba pieczona"];
const SWAP_FEE_NAME = "Zamiana w zestawie";

/** Cennik dodatków (poza sosami) */
const EXTRA_PRICES: Record<string, number> = {
  Tempura: 4,
  "Płatek sojowy": 4,
  Tamago: 4,
  "Ryba pieczona": 2, // zawsze 2 zł
};

/* NOWE: nazwy addonów dla pieczenia zestawów/rolek */
const RAW_SET_BAKE_ALL = "Zamiana całego zestawu na pieczony";
const RAW_SET_BAKE_ALL_LEGACY =
  "Zamiana całego zestawu surowego na pieczony (+5 zł)"; // dla starych zamówień
const RAW_SET_BAKE_ROLL_PREFIX = "Zamiana surowej rolki na pieczoną: ";

/** Dodatki przypisane do konkretnej rolki w zestawie */
const SET_ROLL_EXTRA_PREFIX = "Dodatek do rolki: ";

/** Addon oznaczający powiększenie zestawu (np. +6 szt za 1 zł) */
const SET_UPGRADE_ADDON = "Powiększenie zestawu";

/* NOWE: bazowe opcje do tatara – bez dopłaty */
const TARTAR_BASES = [
  "Podanie: na awokado",
  "Podanie: na ryżu",
  "Podanie: na chipsach krewetkowych",
];

/** Dopłata za wersję pieczoną całego zestawu – per zestaw (z menu) */
const SET_BAKE_PRICES: Record<string, number> = {
  "zestaw 2": 2,
  "zestaw 5": 6,
  "zestaw 7": 2,
  "zestaw 10": 2,
  "zestaw 11": 8,
  "zestaw 12": 4,
  "zestaw 13": 8,
};

type SetUpgradeInfo = {
  basePieces: number;
  extraPieces: number;
  totalPieces: number;
  price: number; // dopłata w zł
};

/**
 * Parsuje opis typu:
 * "28 szt + 6 szt za 1 zł = 34 szt 129 zł ..."
 * "72 szt + 14 szt za 2 zł = 86 szt 279 zł ..."
 */
function parseSetUpgradeInfo(
  product?: ProductDb | null
): SetUpgradeInfo | null {
  if (!product?.description) return null;
  const text = product.description.toLowerCase().replace(",", ".");

  const re =
    /(\d+)\s*szt[^+\d]*\+\s*(\d+)\s*szt\s*za\s*(\d+)\s*zł[^=]*=\s*(\d+)\s*szt/;
  const m = text.match(re);
  if (!m) return null;

  const basePieces = Number(m[1]);
  const extraPieces = Number(m[2]);
  const price = Number(m[3]);
  const totalPieces = Number(m[4]);

  if (
    !Number.isFinite(basePieces) ||
    !Number.isFinite(extraPieces) ||
    !Number.isFinite(price)
  ) {
    return null;
  }

  return { basePieces, extraPieces, totalPieces, price };
}

function getSetUpgradePrice(product?: ProductDb | null): number | null {
  const info = parseSetUpgradeInfo(product || null);
  return info ? info.price : null;
}

function getSetBakePriceForProduct(product?: ProductDb | null): number | null {
  if (!product) return null;
  const name = product.name.toLowerCase();
  for (const key of Object.keys(SET_BAKE_PRICES)) {
    if (name.startsWith(key)) {
      return SET_BAKE_PRICES[key];
    }
  }
  return null;
}

/* Helper: rozpoznanie specjalnej California z opcją Ryby pieczonej +2 zł
   – po składnikach, bez wymogu słowa "California" w nazwie */
function isSpecialCaliforniaBakedFishProduct(
  name: string,
  description?: string | null
): boolean {
  const text = `${name} ${description || ""}`.toLowerCase();

  // łosoś + info, że jest surowy
  const hasSalmon =
    text.includes("łosoś") || text.includes("losos");
  const isRaw =
    text.includes("surowy") ||
    text.includes("surowe") ||
    text.includes("surowa") ||
    text.includes("surow");

  // paluszek krabowy / krab – różne odmiany
  const hasCrab =
    text.includes("paluszek krabowy") ||
    text.includes("paluszki krabowe") ||
    text.includes("paluszkiem krabowym") ||
    text.includes("krabowy") ||
    text.includes("krab");

  // krewetka / krewetki – łapiemy po "krewet"
  const hasShrimp = text.includes("krewet");

  return hasSalmon && isRaw && hasCrab && hasShrimp;
}

function computeAddonPrice(addon: string, product?: ProductDb | null): number {
  if (ALL_SAUCES.includes(addon)) return 3;
  if (addon === SWAP_FEE_NAME) return 5;

  // Bazowe opcje podania tatara – 0 zł
  if (TARTAR_BASES.includes(addon)) return 0;

  // Wersja pieczona całego zestawu – cena zależy od konkretnego zestawu
  if (addon === RAW_SET_BAKE_ALL || addon === RAW_SET_BAKE_ALL_LEGACY) {
    const p = getSetBakePriceForProduct(product || null);
    return typeof p === "number" ? p : 5;
  }

  // Powiększony zestaw (np. "+6 szt za 1 zł", "+14 szt za 2 zł")
  if (addon === SET_UPGRADE_ADDON) {
    const p = getSetUpgradePrice(product || null);
    return typeof p === "number" ? p : 1; // fallback 1 zł
  }

  // pojedyncza surowa rolka w zestawie -> pieczona
  if (addon.startsWith(RAW_SET_BAKE_ROLL_PREFIX)) return 2;

  // ----- Dodatki typu Tempura / Płatek sojowy / Tamago / Ryba pieczona -----
  // Mogą występować:
  // - jako sam addon ("Tempura", "Ryba pieczona")
  // - jako addon per rolka w zestawie: "Dodatek do rolki: <cat> <opis> — <nazwa dodatku>"

  let label = addon;

  if (addon.startsWith(SET_ROLL_EXTRA_PREFIX)) {
    const after = addon.slice(SET_ROLL_EXTRA_PREFIX.length).trim();
    const parts = after.split("—");
    const maybeExtra = (parts[1] || parts[0] || "").trim();
    const foundBase = EXTRAS.find((ex) =>
      maybeExtra.toLowerCase().includes(ex.toLowerCase())
    );
    if (foundBase) {
      label = foundBase; // "Tempura" / "Płatek sojowy" / "Tamago" / "Ryba pieczona"
    }
  }

  const extraPrice = EXTRA_PRICES[label as keyof typeof EXTRA_PRICES];
  if (typeof extraPrice === "number") return extraPrice;

  // Fallback – gdyby pojawił się nieskonfigurowany addon
  return 4;
}

/* helper dla widoczności elementu (używany przez Turnstile) */
const isVisible = (el: HTMLDivElement | null) => !!el && !!el.offsetParent;

/* ---------- helpers ---------- */
const accentBtn =
  "bg-gradient-to-b from-[#b31217] to-[#7a0b0b] text-white shadow-[0_10px_22px_rgba(0,0,0,.35),inset_0_1px_0_rgba(255,255,255,.15)] ring-1 ring-black/30";

/* ================= GODZINY OTWARCIA PER MIASTO ================= */
type Day = 0 | 1 | 2 | 3 | 4 | 5 | 6; // 0 = niedziela
type Range = [h: number, m: number, H: number, M: number];

const CITY_SCHEDULE: Record<
  string,
  Partial<Record<Day, Range>> & { default?: Range }
> = {
  ciechanow: {
    0: [12, 0, 20, 30],
    1: [12, 0, 20, 30],
    2: [12, 0, 20, 30],
    3: [12, 0, 20, 30],
    4: [12, 0, 21, 30],
    5: [12, 0, 20, 30],
    6: [12, 0, 20, 30],
  },
  przasnysz: { default: [12, 0, 20, 30] },
  szczytno: { default: [12, 0, 20, 30] },
};

const tz = "Europe/Warsaw";
const pad = (n: number) => String(n).padStart(2, "0");
const fmt = (r: Range) => `${pad(r[0])}:${pad(r[1])}–${pad(r[2])}:${pad(r[3])}`;
const MIN_SCHEDULE_MINUTES = 60;

function todayRangeFor(slug: string, d = toZonedTime(new Date(), tz)): Range | null {
  const sch = CITY_SCHEDULE[slug] ?? CITY_SCHEDULE["przasnysz"];
  const r = sch[d.getDay() as Day] ?? sch.default ?? null;
  return r ?? null;
}

function isOpenFor(slug: string, d = toZonedTime(new Date(), tz)) {
  const r = todayRangeFor(slug, d);
  if (!r) return { open: false, label: "zamknięte", range: null as Range | null };
  const mins = d.getHours() * 60 + d.getMinutes();
  const o = r[0] * 60 + r[1];
  const c = r[2] * 60 + r[3];
  return { open: mins >= o && mins <= c, label: fmt(r), range: r };
}
/* ================================================================= */

/* Czas dostawy wskazany przez klienta */
const buildClientDeliveryTime = (
  selectedOption: OrderOption | null,
  deliveryTimeOption: "asap" | "schedule",
  scheduledTime: string
): string | null => {
  if (selectedOption !== "delivery") return null;
  if (deliveryTimeOption === "asap") return "asap";
  const [hours, minutes] = scheduledTime.split(":").map(Number);
  const nowZoned = toZonedTime(new Date(), tz);
  const dt = new Date(nowZoned);
  dt.setHours(hours, minutes, 0, 0);
  if (dt.getTime() < nowZoned.getTime()) dt.setDate(dt.getDate() + 1);
  return dt.toISOString();
};

const safeFetch = async (url: string, opts: RequestInit) => {
  const res = await fetch(url, { credentials: "same-origin", ...opts });
  const text = await res.text();
  let data: any;
  try {
    data = JSON.parse(text);
  } catch {
    data = { raw: text };
  }
  if (!res.ok) throw new Error(data?.error || data?.message || `HTTP ${res.status}`);
  return data;
};

/** Etykieta i slug restauracji z pierwszego segmentu URL */
function getRestaurantCityFromPath(): { slug: string; label: string } {
  if (typeof window === "undefined") return { slug: "", label: "wybranym mieście" };
  const first = window.location.pathname.split("/").filter(Boolean)[0] || "";
  const slug = first.toLowerCase();
  const MAP: Record<string, string> = {
    ciechanow: "Ciechanów",
    szczytno: "Szczytno",
    przasnysz: "Przasnysz",
  };
  const label =
    MAP[slug] ||
    (slug ? slug.replace(/-/g, " ").replace(/^\w/, (c) => c.toUpperCase()) : "wybranym mieście");
  return { slug, label };
}

/* prosty hook do wykrycia mobile (Tailwind lg = 1024) */
function useIsMobile(breakpoint = 1024) {
  const [isMobile, setIsMobile] = React.useState(false);
  React.useEffect(() => {
    if (typeof window === "undefined") return;
    const mq = window.matchMedia(`(max-width:${breakpoint - 1}px)`);

    const update = () => setIsMobile(mq.matches);
    update();
    mq.addEventListener?.("change", update);
    return () => mq.removeEventListener?.("change", update);
  }, [breakpoint]);
  return isMobile;
}

/* Kontrolka ilości pałeczek – używana w podsumowaniu / koszyku */
function ChopsticksControl({
  value,
  onChange,
}: {
  value: number;
  onChange: (v: number) => void;
}) {
  const clamp = (n: number) => Math.max(0, Math.min(10, n));
  const dec = () => onChange(clamp(value - 1));
  const inc = () => onChange(clamp(value + 1));

  return (
    <div className="mt-4 space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-black">Ilość pałeczek</span>
        <span className="text-[11px] text-black/60">
          0 = nie potrzebuję
        </span>
      </div>
      <div className="flex items-center justify-center gap-4">
        <button
          type="button"
          onClick={dec}
          className="h-11 w-11 rounded-[20px] border border-black/20 bg-transparent text-white text-xl flex items-center justify-center"
        >
          –
        </button>
        <div className="min-w-[56px] text-center text-lg font-semibold">
          {value}
        </div>
        <button
          type="button"
          onClick={inc}
          className="h-11 w-11 rounded-full border border-black/20 bg-black text-white text-xl flex items-center justify-center"
        >
          +
        </button>
      </div>
    </div>
  );
}


/* ===== utile produktu i zestawu ===== */
const normalize = (s: string) => s.toLowerCase();

/* NOWE: prefiks kategorii w nazwach (Futomak, Hosomak, California, Nigiri) */
const CATEGORY_PREFIX: Record<string, string> = {
  futomaki: "Futomak",
  hosomaki: "Hosomak",
  california: "California",
  nigiri: "Nigiri",
};

/** Spróbuj odgadnąć kategorię po samej nazwie produktu */
function inferCategoryFromName(name?: string | null): string | null {
  if (!name) return null;
  const n = name.toLowerCase().trim();

  if (n.startsWith("futomak")) return "futomaki";
  if (n.startsWith("hosomak")) return "hosomaki";
  if (n.startsWith("california")) return "california";
  if (n.startsWith("nigiri")) return "nigiri";

  return null;
}

/** Dodaje prefiks kategorii do nazwy, jeśli nie jest już zawarty */
function withCategoryPrefix(name: string, subcategory?: string | null): string {
  const base = (name || "").trim();
  if (!base) return base;

  const lowerBase = base.toLowerCase();

  // jeśli nazwa już zawiera jakikolwiek znany prefiks – zostawiamy jak jest
  const alreadyPrefixed = [
    "futomak ",
    "futomaki ",
    "hosomak ",
    "california ",
    "nigiri ",
  ].some((p) => lowerBase.startsWith(p));
  if (alreadyPrefixed) return base;

  // najpierw kategoria z nazwy, dopiero potem z pola subcategory
  const inferred = inferCategoryFromName(base);
  const key = (inferred || (subcategory || "").toLowerCase()) as keyof typeof CATEGORY_PREFIX;
  const prefix = CATEGORY_PREFIX[key];
  if (!prefix) return base;

  const capitalized = base[0].toUpperCase() + base.slice(1);
  return `${prefix} ${capitalized}`;
}

function parseSetComposition(desc?: string | null) {
  if (!desc) {
    return [] as { qty: number; cat: string; from: string }[];
  }

  // przykład: "16 szt, SUROWY: 6x Futomaki łosoś philadelphia surowy, 8x Hosomaki ogórek, +6x Futomaki krewetka w tempurze za 1 zł!"
  const listPart = desc.split(":").slice(1).join(":") || desc;

  const rows: { qty: number; cat: string; from: string }[] = [];

  // Szukamy wszystkich sekwencji typu:
  // "+6x Futomaki krewetka w tempurze za 1 zł"
  // "8x Hosomaki ogórek"
  //
  // Działa nawet jeśli zapisy są sklejone bez przecinka:
  // "8x Hosomaki ogórek +6x Futomaki krewetka..."
  const re =
    /[+\-–•]?\s*(\d+)\s*x\s*(Futomaki|California|Hosomaki|Nigiri)\s+(.+?)(?=(?:[,;\n]|[+\-–•]\s*\d+\s*x\s*(?:Futomaki|California|Hosomaki|Nigiri)|$))/gi;

  let m: RegExpExecArray | null;
  while ((m = re.exec(listPart)) !== null) {
    const qty = parseInt(m[1], 10) || 1;
    const cat = m[2];

    // obcinamy końcówki typu "za 1 zł!", "za 2zl" itd.
    const from = m[3]
      .replace(/\s+za\s*\d+\s*z[łl].*$/i, "")
      .trim();

    if (!from) continue;

    rows.push({ qty, cat, from });
  }

  return rows;
}

type SetSwapPayload = {
  qty: number;
  from: string;     // np. "Futomaki łosoś philadelphia surowy"
  to: string;       // np. "Futomak Vege"
  addons?: string[]; // np. ["Tempura", "Płatek sojowy"]
};

/** Kopia logiki klucza z ProductItem.normalizeSetRowKey – tylko na potrzeby payloadu */
function normalizeSetRowKeyForPayload(row: {
  qty: number;
  cat: string;
  from: string;
}): string {
  const cat = (row.cat || "").trim();
  const from = (row.from || "").trim();
  if (!from) return cat;

  const parts = from
    .split("+")
    .map((p) => p.trim())
    .filter(Boolean);

  const isFishPart = (s: string) => {
    const l = s.toLowerCase();
    return (
      l.includes("łosoś") ||
      l.includes("losos") ||
      l.includes("tuńczyk") ||
      l.includes("tunczyk")
    );
  };

  if (parts.length > 1) {
    const fishParts = parts.filter(isFishPart);
    if (fishParts.length === 1) {
      return `${cat} ${fishParts[0]}`.replace(/\s+/g, " ").trim();
    }
    if (fishParts.length > 1) {
      return `${cat} ${fishParts.join(" + ")}`.replace(/\s+/g, " ").trim();
    }
  }

  return `${cat} ${from}`.replace(/\s+/g, " ").trim();
}

/** Buduje strukturalne info o zamianach w zestawie + dodatkach per rolka dla danej pozycji z koszyka */
function buildSetSwapsPayload(
  item: any,
  product?: ProductDb | undefined
): SetSwapPayload[] {
  if (!product) return [];
  const subcat = (product.subcategory || "").toLowerCase();
  if (subcat !== "zestawy") return [];

  const rows = parseSetComposition(product.description);
  if (!rows.length) return [];

  const swapsArr = Array.isArray(item.swaps) ? item.swaps : [];
  const addonsArr = Array.isArray(item.addons) ? item.addons : [];

  const result: SetSwapPayload[] = [];

  rows.forEach((row) => {
    const baseLabel = `${row.cat} ${row.from}`.replace(/\s+/g, " ").trim();

    const foundSwap = swapsArr.find(
      (s: any) =>
        s &&
        typeof s.from === "string" &&
        s.from.toLowerCase() === row.from.toLowerCase()
    );

    const toLabel = (foundSwap?.to as string) || row.from;

    const rowKeyBase = normalizeSetRowKeyForPayload(row);
    const prefix = `${SET_ROLL_EXTRA_PREFIX}${rowKeyBase} — `;
    const rowExtras = addonsArr
      .filter(
        (a: any) => typeof a === "string" && (a as string).startsWith(prefix)
      )
      .map((a: any) => (a as string).slice(prefix.length).trim())
      .filter(Boolean);

    result.push({
      qty: row.qty,
      from: baseLabel,
      to: toLabel,
      addons: rowExtras.length ? rowExtras : undefined,
    });
  });

  return result;
}

/** Ładny tekst do notatki (kitchen_note / panel) z listy zamian */
function buildSetSwapsNote(swaps: SetSwapPayload[]): string {
  if (!swaps || !swaps.length) return "";
  return swaps
    .map((s) => {
      const addons =
        s.addons && s.addons.length
          ? ` (+ ${s.addons.join(", ")})`
          : "";
      return `${s.qty}× ${s.from} → ${s.to}${addons}`;
    })
    .join("; ");
}

function isAlreadyBakedOrTempura(text: string): boolean {
  const t = (text || "").toLowerCase();
  const hasBaked = t.includes("pieczon"); // pieczona / pieczony / pieczone
  const hasTempura = t.includes("tempur"); // tempura / w tempurze
  return hasBaked || hasTempura;
}

/* ---------- Item w koszyku ---------- */
const ProductItem: React.FC<{
  prod: any;
  productCategory: (name: string) => string;
  productsDb: ProductDb[];
  optionsByCat: Record<string, string[]>;
  restaurantSlug: string;
  helpers: {
    addAddon: (name: string, addon: string) => void;
    removeAddon: (name: string, addon: string) => void;
    swapIngredient: (name: string, from: string, to: string) => void;
    removeItem: (name: string) => void;
    removeWholeItem: (name: string) => void;
  };
}> = ({
  prod,
  productCategory,
  productsDb,
  optionsByCat,
  restaurantSlug,
  helpers,
}) => {
  const { addAddon, removeAddon, swapIngredient, removeItem, removeWholeItem } =
    helpers;

  const byName = useMemo(() => {
    const map = new Map<string, ProductDb>();
    productsDb.forEach((p) => map.set(p.name, p));
    return map;
  }, [productsDb]);

  const byId = useMemo(() => {
    const map = new Map<string, ProductDb>();
    productsDb.forEach((p) => map.set(p.id, p));
    return map;
  }, [productsDb]);

  const prodInfo =
    (prod.product_id && byId.get(prod.product_id)) ||
    (prod.id && byId.get(prod.id)) ||
    (prod.baseName && byName.get(prod.baseName)) ||
    byName.get(prod.name);

   // kategoria: najpierw po nazwie, potem z bazy
  const inferredCat = inferCategoryFromName(prodInfo?.name || prod.name);
  const subcat = (inferredCat || prodInfo?.subcategory || "").toLowerCase();

  const isSet = subcat === "zestawy";
  const isSpec = subcat === "specjały";

  const productSubcat =
    inferredCat ||
    prodInfo?.subcategory ||
    productCategory(prod.baseName || prod.name);

  const singleCurrentName = useMemo(() => {
    if (isSet || isSpec) return prod.name as string;
    const swaps = Array.isArray((prod as any).swaps)
      ? (prod as any).swaps
      : [];
    const found = swaps.find(
      (s: any) =>
        s &&
        typeof s.from === "string" &&
        s.from.toLowerCase() === (prod.name || "").toLowerCase()
    );
    return (found?.to as string) || prod.name;
  }, [isSet, isSpec, prod.swaps, prod.name]);

  const setRows = useMemo(
    () => (isSet ? parseSetComposition(prodInfo?.description) : []),
    [isSet, prodInfo?.description]
  );

  const normalizeSetRowKey = (
    row: { qty: number; cat: string; from: string }
  ) => {
    const cat = (row.cat || "").trim();
    const from = (row.from || "").trim();
    if (!from) return cat;

    // rozbijamy po "+" bo w zestawach często są miksy typu
    // "krewetka + łosoś surowy"
    const parts = from.split("+").map((p) => p.trim()).filter(Boolean);

    const isFishPart = (s: string) => {
      const l = s.toLowerCase();
      return (
        l.includes("łosoś") ||
        l.includes("losos") ||
        l.includes("tuńczyk") ||
        l.includes("tunczyk")
      );
    };

    if (parts.length > 1) {
      const fishParts = parts.filter(isFishPart);
      if (fishParts.length === 1) {
        // preferujemy część z łososiem / tuńczykiem
        return `${cat} ${fishParts[0]}`.replace(/\s+/g, " ").trim();
      }
      if (fishParts.length > 1) {
        return `${cat} ${fishParts.join(" + ")}`.replace(/\s+/g, " ").trim();
      }
    }

    // fallback: cały opis, ale znormalizowane spacje
    return `${cat} ${from}`.replace(/\s+/g, " ").trim();
  };

  // dopłata za wersję pieczoną całego zestawu (jeśli jest przewidziana w menu)
  const setBakePrice = isSet ? getSetBakePriceForProduct(prodInfo) : null;

  // info o powiększeniu (np. 28 szt + 6 szt za 1 zł = 34 szt)
  const setUpgradeInfo = isSet ? parseSetUpgradeInfo(prodInfo) : null;

  const isWholeSetBaked =
    (prod.addons ?? []).includes(RAW_SET_BAKE_ALL) ||
    (prod.addons ?? []).includes(RAW_SET_BAKE_ALL_LEGACY);

  const isSetUpgraded = (prod.addons ?? []).includes(SET_UPGRADE_ADDON);

  const isRawRow = (row: { qty: number; cat: string; from: string }) =>
    /surowy/i.test(row.from);

  const getSetSwapCurrent = (rowFrom: string): string => {
    const swaps = Array.isArray(prod.swaps) ? prod.swaps : [];
    const found = swaps.find(
      (s: any) =>
        s &&
        typeof s.from === "string" &&
        s.from.toLowerCase() === rowFrom.toLowerCase()
    );
    return (found?.to as string) || rowFrom;
  };

  const priceNum =
    typeof prod.price === "string" ? parseFloat(prod.price) : prod.price || 0;
  const addonsCost = (prod.addons ?? []).reduce((sum: number, addon: string) => {
    const unit = computeAddonPrice(addon, prodInfo || undefined);
    return sum + unit;
  }, 0);
  const lineTotal = (priceNum + addonsCost) * (prod.quantity || 1);

  // Czy dany extra jest dozwolony dla tego produktu
  const canUseExtra = (extra: string): boolean => {
    if (isSet) {
      // w zestawach używamy canUseExtraForRow (per rolka)
      return false;
    }

    if (!prodInfo) return false;

    const catForLogic =
      inferCategoryFromName(prodInfo.name) ||
      inferCategoryFromName(prod.name) ||
      prodInfo.subcategory ||
      subcat ||
      "";

    const s = catForLogic.toLowerCase();

    // === California ===
    if (s.includes("california")) {
      if (extra === "Ryba pieczona") {
        const text = `${prod.name} ${prodInfo.description || ""}`;
        // jeśli ta California jest już pieczona / w tempurze – nie dokładamy „Ryby pieczonej”
        if (isAlreadyBakedOrTempura(text)) return false;

        return isSpecialCaliforniaBakedFishProduct(
          prod.name,
          prodInfo.description || ""
        );
      }
      // do California nie dokładamy innych EXTRAS poza tą jedną opcją
      return false;
    }

    // === Hosomaki / Hoso ===
    if (s.includes("hoso")) {
      // Hoso mają tylko Tempurę
      return extra === "Tempura";
    }

    // === Futomaki / Futo ===
    if (s.includes("futo")) {
      if (extra === "Ryba pieczona") {
        const text = `${prod.name} ${prodInfo.description || ""}`;
        // jeśli futomak jest już pieczony / w tempurze – nie pokazujemy „Ryby pieczonej”
        if (isAlreadyBakedOrTempura(text)) return false;
        // tylko przy surowych futomakach
        return /surowy/i.test(text);
      }
      if (extra === "Tamago") return true;
      return extra === "Tempura" || extra === "Płatek sojowy";
    }

    // === Nigiri ===
    if (s.includes("nigiri")) {
      // Nigiri z łososiem / tuńczykiem – tylko Ryba pieczona (opalana)
      const text = `${prodInfo.name} ${prodInfo.description || ""}`.toLowerCase();
      const fishNigiri =
        text.includes("łosoś") ||
        text.includes("losos") ||
        text.includes("tuńczyk") ||
        text.includes("tunczyk");
      return extra === "Ryba pieczona" && fishNigiri;
    }

    return false;
  };

  const doSetSwap = (rowFrom: string, to: string) => {
    const current = getSetSwapCurrent(rowFrom);
    if (!to || to === current) return;

    // ważne: backend/store trzyma zamianę po ORYGINALNEJ nazwie z opisu zestawu
    swapIngredient(prod.name, rowFrom, to);

    // jednorazowa opłata za zamiany w zestawie
    if (!(prod.addons ?? []).includes(SWAP_FEE_NAME)) {
      addAddon(prod.name, SWAP_FEE_NAME);
    }
  };

  // Frytki z batatów z przystawek – tylko w Szczytnie i Przasnyszu
   const isSweetPotatoFries = useMemo(() => {
    const city = (restaurantSlug || "").toLowerCase();
    if (city !== "szczytno" && city !== "przasnysz") return false;

    // bierzemy nazwę z koszyka + ewentualnie z bazy
    const text = `${prod.name || ""} ${
      prodInfo?.name || ""
    } ${prodInfo?.description || ""}`.toLowerCase();

    return (
      text.includes("frytki z batat") ||
      text.includes("frytki batat")
    );
  }, [prod, prodInfo, restaurantSlug]);

  const saucesForProduct = useMemo(() => {
    if (isSweetPotatoFries) {
      // tu pokazujemy tylko te 4 sosy do batatów
      return ["Spicy Mayo", "Teryiaki", "Sos czekoladowy", "Sos toffi"];
    }
    // standardowy zestaw sosów
    return BASE_SAUCES;
  }, [isSweetPotatoFries]);

  // Tatar: tylko w Szczytnie / Przasnyszu, przystawki + tatar z łososia/tuńczyka
 // Tatar: tylko w Szczytnie / Przasnyszu, przystawki + tatar z łososia/tuńczyka
 // Tatar: tylko w Szczytnie / Przasnyszu, przystawki + tatar z łososia/tuńczyka
  const isTartar = useMemo(() => {
    if (!prodInfo) return false;

    const sub = (prodInfo.subcategory || "").toLowerCase();
    // ważne: fragment "przystawk" łapie "Przystawka", "Przystawki" itd.
    if (!sub.includes("przystawk")) return false;

    const city = (restaurantSlug || "").toLowerCase();
    if (city !== "szczytno" && city !== "przasnysz") return false;

    const text = `${prodInfo.name} ${prodInfo.description || ""}`.toLowerCase();
    if (!text.includes("tatar")) return false;

    const hasFish =
      text.includes("łosoś") ||
      text.includes("łososia") ||
      text.includes("losos") ||
      text.includes("lososia") ||
      text.includes("łososi") ||
      text.includes("lososi") ||
      text.includes("tuńczyk") ||
      text.includes("tunczyk") ||
      text.includes("tuńczyka") ||
      text.includes("tunczyka");

    return hasFish;
  }, [prodInfo, restaurantSlug]);

  const toggleAddon = (a: string) => {
    const on = (prod.addons ?? []).includes(a);
    const allowed = EXTRAS.includes(a) ? canUseExtra(a) : true;
    if (!allowed) return;
    if (on) removeAddon(prod.name, a);
    else addAddon(prod.name, a);
  };

  const toggleWholeSetBake = () => {
    const on = isWholeSetBaked;
    if (on) {
      // zdejmujemy oba możliwe labele, na wszelki wypadek
      removeAddon(prod.name, RAW_SET_BAKE_ALL);
      removeAddon(prod.name, RAW_SET_BAKE_ALL_LEGACY);
    } else {
      addAddon(prod.name, RAW_SET_BAKE_ALL);
      // przy wersji pieczonej całego zestawu wyłączamy pieczenie pojedynczych rolek
      setRows.forEach((row) => {
        const rowKeyBase = normalizeSetRowKey(row);
        const label = RAW_SET_BAKE_ROLL_PREFIX + rowKeyBase;
        if ((prod.addons ?? []).includes(label)) {
          removeAddon(prod.name, label);
        }
      });
    }
  };

  const setSetSize = (upgraded: boolean) => {
    if (!setUpgradeInfo) return;
    if (upgraded) {
      if (!isSetUpgraded) addAddon(prod.name, SET_UPGRADE_ADDON);
    } else {
      if (isSetUpgraded) removeAddon(prod.name, SET_UPGRADE_ADDON);
    }
  };

  // WYŚWIETLANA NAZWA W KOSZYKU: kategoria + nazwa (dla pojedynczych rolek)
  const displayTitle = useMemo(() => {
    if (isSet || isSpec) return prod.name as string;
    return withCategoryPrefix(singleCurrentName, productSubcat);
  }, [isSet, isSpec, prod.name, singleCurrentName, productSubcat]);

  return (
    <div className="border border-black/10 bg-white p-3">
      <div className="flex justify-between items-center font-semibold mb-2">
        <span className="text-black">
          {displayTitle} x{prod.quantity || 1}
        </span>
        <span className="text-black">
          {lineTotal.toFixed(2).replace(".", ",")} zł
        </span>
      </div>

      <div className="text-xs text-black/80 space-y-3">
        {isSet && setRows.length > 0 && (
          <div className="space-y-2">
            <div className="font-semibold">Zamiany w zestawie</div>
            {setRows.map((row, i) => {
              const catKey = normalize(row.cat);
              const pool = (optionsByCat[catKey] || []).filter(
                (n) =>
                  (productCategory(n) || "").toLowerCase() !== "specjały"
              );
              const current = getSetSwapCurrent(row.from);

              // znormalizowany klucz tej rolki w zestawie
              const rowKeyBase = normalizeSetRowKey(row);

              // pieczenie konkretnej rolki w zestawie
              const rollAddonLabel = RAW_SET_BAKE_ROLL_PREFIX + rowKeyBase;
              const rawRow = isRawRow(row);
              const rollBaked = (prod.addons ?? []).includes(rollAddonLabel);

              const toggleRowBake = () => {
                if (!rawRow || isWholeSetBaked) return;
                if (rollBaked) {
                  removeAddon(prod.name, rollAddonLabel);
                } else {
                  addAddon(prod.name, rollAddonLabel);
                }
              };

              // Dodatki per konkretna rolka w zestawie – ten sam znormalizowany klucz
              const extraKey = (ex: string) =>
                `${SET_ROLL_EXTRA_PREFIX}${rowKeyBase} — ${ex}`;

              // BIERZEMY aktualnie wybraną rolkę w tym miejscu zestawu:
const currentProduct =
  byName.get(current) || byName.get(row.from) || prodInfo;

// kategorię bierzemy z opisu zestawu (row.cat),
// bo produkt "Zestaw X" ma subcategory = "zestawy"
const rowCatLc = (row.cat || "").toLowerCase();

// tekst do sprawdzania "surowy", "łosoś" itd.
const text = `${currentProduct?.name || row.cat} ${
  currentProduct?.description || row.from
}`.toLowerCase();

const canUseExtraForRow = (ex: string): boolean => {
  const parentNameLc = (prodInfo?.name || prod.name || "").toLowerCase();

  // SPEC CASE: w Zestawie 2 hosomaki bez dodatków (w tym „Ryba pieczona”)
  if (parentNameLc.startsWith("zestaw 2") && rowCatLc.includes("hosomaki")) {
    return false;
  }

  // === California w zestawie ===
  if (rowCatLc.includes("california")) {
    if (ex === "Ryba pieczona") {
      const rowText = row.from.toLowerCase();
      // jeśli ta California w zestawie jest już pieczona / w tempurze – blokujemy
      if (isAlreadyBakedOrTempura(rowText)) return false;

      return isSpecialCaliforniaBakedFishProduct(
        currentProduct?.name || "",
        currentProduct?.description || ""
      );
    }
    // inne EXTRAS wyłączone dla California w zestawach
    return false;
  }

  // === Hosomaki / Hoso ===
  if (rowCatLc.includes("hosomaki") || rowCatLc.includes("hoso")) {
    // Hoso mają tylko Tempurę
    return ex === "Tempura";
  }

  // === Futomaki / Futo ===
  if (rowCatLc.includes("futomaki") || rowCatLc.includes("futo")) {
    if (ex === "Ryba pieczona") {
      const rowText = row.from.toLowerCase();
      // jeśli ta rolka w opisie ma „pieczona” lub „w tempurze” – nie dokładamy „Ryby pieczonej”
      if (isAlreadyBakedOrTempura(rowText)) return false;
      // tylko przy surowych futomakach (sprawdzamy opis KONKRETNEJ rolki, nie całego zestawu)
      return /surowy/i.test(rowText);
    }
    if (ex === "Tamago") return true;
    return ex === "Tempura" || ex === "Płatek sojowy";
  }

  // === Nigiri – logika bez zmian ===
  if (rowCatLc.includes("nigiri")) {
    if (ex !== "Ryba pieczona") return false;
    const hasFish =
      text.includes("łosoś") ||
      text.includes("losos") ||
      text.includes("tuńczyk") ||
      text.includes("tunczyk");
    return hasFish;
  }

  return false;
};

             const isCaliforniaRow = /california/i.test(row.cat || "");

              return (
                <div key={i} className="flex flex-col gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2 py-1 rounded bg-gray-50 border border-gray-200">
                      {row.qty}× {row.cat}
                    </span>

                    {isCaliforniaRow ? (
                      // Dla Californii w zestawach nie ma pełnej zamiany – pokazujemy tylko opis
                      <span className="text-black/70 text-[11px]">
                        {row.from}
                      </span>
                    ) : (
                      <>
                        <span className="text-black/70">zamień:</span>
                        <select
                          className="border border-black/15 rounded px-2 py-1 bg-white"
                          value={current}
                          onChange={(e) => doSetSwap(row.from, e.target.value)}
                        >
                          {[current, ...pool.filter((n) => n !== current)].map(
                            (n) => (
                              <option key={n} value={n}>
                                {withCategoryPrefix(n, row.cat)}
                              </option>
                            )
                          )}
                        </select>
                      </>
                    )}

                    {rawRow && (
                      <button
                        type="button"
                        onClick={toggleRowBake}
                        disabled={isWholeSetBaked}
                        className={clsx(
                          "px-2 py-1 rounded text-[11px] border",
                          isWholeSetBaked
                            ? "opacity-40 cursor-not-allowed bg-gray-50 border-gray-200"
                            : rollBaked
                            ? "bg-black text-white border-black"
                            : "bg-white text-black hover:bg-gray-50 border-gray-200"
                        )}
                      >
                        {rollBaked
                          ? "✓ Ta rolka pieczona (+2 zł)"
                          : "+ Zamień tę rolkę na pieczoną (+2 zł)"}
                      </button>
                    )}
                  </div>

                  {/* Dodatki dla tej KONKRETNEJ rolki */}
                  <div className="flex flex-wrap items-center gap-2 pl-2">
                    <span className="text-black/70 text-[11px]">
                      Dodatki do tej rolki:
                    </span>
                    {EXTRAS.map((ex) => {
                      const key = extraKey(ex);
                      const allowed = canUseExtraForRow(ex);
                      const on = (prod.addons ?? []).includes(key);
                      return (
                        <button
                          key={ex}
                          type="button"
                          onClick={() => {
                            if (!allowed) return;
                            if (on) removeAddon(prod.name, key);
                            else addAddon(prod.name, key);
                          }}
                          className={clsx(
                            "px-2 py-1 rounded text-[11px] border",
                            !allowed
                              ? "opacity-40 cursor-not-allowed bg-gray-50 border-gray-200"
                              : on
                              ? "bg-black text-white border-black"
                              : "bg-white text-black hover:bg-gray-50 border-gray-200"
                          )}
                        >
                          {on ? `✓ ${ex}` : `+ ${ex}`}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}

            {/* Rozmiar zestawu: standard vs powiększony (+szt za 1–2 zł) */}
            {setUpgradeInfo && (
              <div className="mt-2 rounded-md border border-emerald-200 bg-emerald-50 px-2 py-2 space-y-1">
                <div className="font-semibold text-[11px]">
                  Rozmiar zestawu:
                </div>
                <div className="flex flex-wrap gap-2 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setSetSize(false)}
                    className={clsx(
                      "px-2 py-1 rounded border",
                      !isSetUpgraded
                        ? "bg-black text-white border-black"
                        : "bg-white text-black hover:bg-gray-50 border-gray-200"
                    )}
                  >
                    Standard – {setUpgradeInfo.basePieces} szt
                  </button>
                  <button
                    type="button"
                    onClick={() => setSetSize(true)}
                    className={clsx(
                      "px-2 py-1 rounded border",
                      isSetUpgraded
                        ? "bg-black text-white border-black"
                        : "bg-white text-black hover:bg-gray-50 border-gray-200"
                    )}
                  >
                    Powiększony – {setUpgradeInfo.totalPieces} szt (
                    +{setUpgradeInfo.extraPieces} szt za{" "}
                    {setUpgradeInfo.price} zł)
                  </button>
                </div>
              </div>
            )}

            <p className="text-[11px] text-black/60">
              Zamiany tylko w obrębie tej samej kategorii (Futomaki ↔ Futomaki,
              Hosomaki ↔ Hosomaki itd.). Californię w zestawach pozostawiamy
              bez zamiany. Bez specjałów. Dodajemy pozycję „{SWAP_FEE_NAME}”.
            </p>

            {isSet && setBakePrice != null && (
              <div className="mt-2 rounded-md border border-orange-200 bg-orange-50 px-2 py-2 space-y-1">
                <div className="font-semibold text-[11px]">
                  Wersja pieczona całego zestawu:
                </div>
                <label className="flex items-center gap-2 text-[11px]">
                  <input
                    type="checkbox"
                    checked={isWholeSetBaked}
                    onChange={toggleWholeSetBake}
                  />
                  <span>
                    Zamień cały zestaw na pieczony (+{setBakePrice} zł)
                  </span>
                </label>
                {isWholeSetBaked && (
                  <p className="text-[10px] text-black/60">
                    Dla całego zestawu naliczana jest jedna dopłata +
                    {setBakePrice} zł. Indywidualne pieczenie pojedynczych
                    rolek w tym wariancie jest wyłączone.
                  </p>
                )}
              </div>
            )}
          </div>
        )}

        <div>
          <div className="font-semibold mb-1">Sosy:</div>
          <div className="flex flex-wrap gap-2">
            {saucesForProduct.map((s) => {
              const on = prod.addons?.includes(s);
              return (
                <button
                  key={s}
                  onClick={() => toggleAddon(s)}
                  className={clsx(
                    "px-2 py-1 rounded text-xs border",
                    on
                      ? "bg-black text-white border-black"
                      : "bg-white text-black hover:bg-gray-50 border-gray-200"
                  )}
                >
                  {on ? `✓ ${s}` : `+ ${s}`}
                </button>
              );
            })}
          </div>
        </div>

        {!isSet && (
          <div>
            <div className="font-semibold mb-1">Dodatki:</div>
            <div className="flex flex-wrap gap-2">
              {EXTRAS.map((ex) => {
                const allowed = canUseExtra(ex);
                const on = prod.addons?.includes(ex);
                return (
                  <button
                    key={ex}
                    onClick={() => allowed && toggleAddon(ex)}
                    className={clsx(
                      "px-2 py-1 rounded text-xs border",
                      !allowed
                        ? "opacity-40 cursor-not-allowed bg-gray-50 border-gray-200"
                        : on
                        ? "bg-black text-white border-black"
                        : "bg-white text-black hover:bg-gray-50 border-gray-200"
                    )}
                  >
                    {on ? `✓ ${ex}` : `+ ${ex}`}
                  </button>
                );
              })}
            </div>

            {subcat === "california" && (
              <p className="text-[11px] text-black/60 mt-1">
                California = rolki z ryżem na zewnątrz. Standardowo nie dodajemy
                do nich dodatków – wyjątek stanowią wybrane pozycje z surowym
                łososiem, paluszkiem krabowym i/lub krewetką obłożoną łososiem.
                Tylko przy takich pozycjach dostępna jest opcja „Ryba pieczona”
                (+2 zł).
              </p>
            )}

            {subcat === "hosomaki" && (
              <p className="text-[11px] text-black/60 mt-1">
                Hosomaki (Hoso) = cienkie rolki z jednym składnikiem. Można
                dodać jedynie Tempurę, a przy zamianach wybierasz wyłącznie inne
                Hosomaki.
              </p>
            )}

            {subcat === "futomaki" && (
              <p className="text-[11px] text-black/60 mt-1">
                Futomaki (Futo) = grubsze rolki z kilkoma składnikami. Dostępne
                dodatki: Tempura, Płatek sojowy, Tamago, a przy rolkach surowych
                także „Ryba pieczona”.
              </p>
            )}

            {isSet && (
              <p className="text-[11px] text-black/60 mt-1">
                W zestawach zamieniasz rolki tylko w obrębie tej samej kategorii
                (Futomaki ↔ Futomaki, Hosomaki ↔ Hosomaki, California ↔
                California, Nigiri ↔ Nigiri). Jeśli w zestawie są Futomaki,
                możesz dodać Tamago, a w zestawach z surową rybą dostępna jest
                opcja „Ryba pieczona” dla wybranych rolek.
              </p>
            )}
          </div>
        )}

               {isTartar && (
          <div>
            <div className="font-semibold mb-1">Sposób podania tatara</div>
            <p className="text-[11px] text-black/60 mt-1">
              Tatar wydajemy standardowo na ryżu. W lokalach w Przasnyszu i
              Szczytnie dokładamy obok chipsy krewetkowe – nie musisz niczego
              zaznaczać w zamówieniu.
            </p>
          </div>
        )}
      </div>

      <div className="flex justify-end items-center mt-2 gap-2 flex-wrap text-[15px]">
        <button
          onClick={() => removeItem(prod.name)}
          className="text-red-600 underline"
        >
          Usuń 1 szt.
        </button>
        <button
          onClick={() => removeWholeItem(prod.name)}
          className="text-red-600 underline"
        >
          Usuń produkt
        </button>
      </div>
    </div>
  );
};

function PromoSection({
  promo,
  promoError,
  onApply,
  onClear,
}: {
  promo: Promo;
  promoError: string | null;
  onApply: (code: string) => void;
  onClear: () => void;
}) {
  const [localCode, setLocalCode] = useState("");
  const deferred = useDeferredValue(localCode);
  const handleApply = useCallback(() => onApply(deferred), [deferred, onApply]);
  const isManual = promo?.require_code ?? false;

  useEffect(() => {
    if (promo && promo.require_code && promo.code) {
      setLocalCode(promo.code);
    } else if (!promo) {
      setLocalCode("");
    }
  }, [promo]);

  return (
    <div className="mt-3">
      <h4 className="font-semibold text-black mb-2">
        {promo && !promo.require_code ? "Promocja" : "Kod promocyjny"}
      </h4>
      <div className="flex gap-2">
        <input
          type="text"
          value={localCode}
          onChange={(e) => setLocalCode(e.target.value)}
          placeholder="Wpisz kod"
          className="flex-1 border border-black/15 rounded-xl px-3 py-2 text-sm bg-white"
          disabled={isManual}
        />
        {isManual ? (
          <button
            onClick={onClear}
            className="px-3 py-2 rounded-xl text-sm border border-black/15"
          >
            Usuń
          </button>
        ) : (
          <button
            onClick={handleApply}
            className={`px-3 py-2 rounded-xl text-sm font-semibold ${accentBtn}`}
          >
            Zastosuj
          </button>
        )}
      </div>
      {promoError && <p className="text-xs text-red-600 mt-1">{promoError}</p>}
      {promo && (
        <p className="text-xs text-green-700 mt-1">
          {promo.require_code ? (
            <>
              Zastosowano kod <b>{promo.code}</b> —{" "}
            </>
          ) : (
            <>Zastosowano promocję automatyczną — </>
          )}
          {promo.type === "percent"
            ? `${promo.value}%`
            : `${promo.value.toFixed(2)} zł`}{" "}
          rabatu.
        </p>
      )}
    </div>
  );
}

/* ---------- Main ---------- */
export default function CheckoutModal() {
  const isClient = useIsClient();
  const session = useSession();
  const isLoggedIn = !!session?.user;
  const supabaseAuth = createClientComponentClient();

  const {
    isCheckoutOpen,
    closeCheckoutModal: originalCloseCheckoutModal,
    checkoutStep,
    goToStep,
    nextStep,
    items,
    clearCart,
    removeItem,
    removeWholeItem,
    addAddon,
    removeAddon,
    swapIngredient,
  } = useCartStore();

  const isMobile = useIsMobile();

  // zamiast useSearchParams – czytamy query przez window.location.search
  const [reservationId, setReservationId] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    const r = params.get("reservation");
    if (!r) {
      setReservationId(null);
      return;
    }
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
      r.trim()
    );
    setReservationId(isUuid ? r.trim() : null);
  }, []);

  const [notes, setNotes] = useState<{ [key: number]: string }>({});
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [contactEmail, setContactEmail] = useState("");

  const [street, setStreet] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [city, setCity] = useState("");
  const [flatNumber, setFlatNumber] = useState("");
  const [optionalAddress, setOptionalAddress] = useState("");

  const [selectedOption, setSelectedOption] = useState<OrderOption | null>(null);
  const [deliveryTimeOption, setDeliveryTimeOption] = useState<"asap" | "schedule">("asap");

  const [productsDb, setProductsDb] = useState<ProductDb[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [restLoc, setRestLoc] = useState<{ lat: number; lng: number } | null>(null);
  const [restaurantId, setRestaurantId] = useState<string | null>(null);
  const [deliveryInfo, setDeliveryInfo] = useState<{ cost: number; eta: string } | null>(null);

  const [legalAccepted, setLegalAccepted] = useState(false);
  const [promo, setPromo] = useState<Promo>(null);
  const [promoError, setPromoError] = useState<string | null>(null);

  const [tsReady, setTsReady] = useState(false);
  const [turnstileToken, setTurnstileToken] = useState<string | null>(null);
  const [turnstileError, setTurnstileError] = useState(false);
  const tsIdRef = useRef<any>(null);
  const tsMobileRef = useRef<HTMLDivElement | null>(null);
  const tsDesktopRef = useRef<HTMLDivElement | null>(null);

  const [deliveryMinOk, setDeliveryMinOk] = useState(true);
  const [deliveryMinRequired, setDeliveryMinRequired] = useState(0);
  const [outOfRange, setOutOfRange] = useState(false);
  const [custCoords, setCustCoords] = useState<{ lat: number; lng: number } | null>(null);

  const sessionEmail = session?.user?.email || "";
  const effectiveEmail = (contactEmail || sessionEmail).trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const validEmail = emailRegex.test(effectiveEmail);

  const { slug: restaurantSlug, label: restaurantCityLabel } = getRestaurantCityFromPath();
  const thanksQrUrl = CITY_REVIEW_QR_URLS[restaurantSlug] || THANKS_QR_URL;
  const restaurantPhone = getRestaurantPhone(restaurantSlug);

  const openInfo = useMemo(() => isOpenFor(restaurantSlug), [restaurantSlug]);
  const timeMin = openInfo.range ? `${pad(openInfo.range[0])}:${pad(openInfo.range[1])}` : "12:00";
  const timeMax = openInfo.range ? `${pad(openInfo.range[2])}:${pad(openInfo.range[3])}` : "23:59";
  const [scheduledTime, setScheduledTime] = useState<string>(timeMin);

const [loyaltyStickers, setLoyaltyStickers] = useState<number | null>(null);
const [loyaltyChoice, setLoyaltyChoice] = useState<LoyaltyChoice>("keep");
const [loyaltyLoading, setLoyaltyLoading] = useState(false);


  useEffect(() => {
    if (deliveryTimeOption === "schedule") {
      setScheduledTime((prev) => {
        const inside = prev >= timeMin && prev <= timeMax;
        return inside ? prev : timeMin;
      });
    }
  }, [timeMin, timeMax, deliveryTimeOption]);

  useEffect(() => {
    if (isLoggedIn && session) {
      setName(session.user.user_metadata?.full_name || "");
      setPhone(session.user.user_metadata?.phone || "");
      setContactEmail(session.user.email || "");
      setStreet(session.user.user_metadata?.street || "");
      setPostalCode(session.user.user_metadata?.postal_code || "");
      setCity(session.user.user_metadata?.city || "");
      setFlatNumber(session.user.user_metadata?.flat_number || "");
    }
  }, [isLoggedIn, session]);

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      // Jeżeli nie ma sluga (np. strona główna) – bierz wszystkie produkty jak do tej pory
      if (!restaurantSlug) {
        const prodRes = await supabase
          .from("products")
          .select("id,name,subcategory,description,restaurant_id");

        if (!cancelled && !prodRes.error && prodRes.data) {
          setProductsDb((prodRes.data as ProductDb[]) || []);
        }
        return;
      }

      // 1) restauracja po slugu
      const restRes = await supabase
        .from("restaurants")
        .select("id, lat, lng")
        .eq("slug", restaurantSlug)
        .maybeSingle();

      if (cancelled || restRes.error || !restRes.data) return;
      const rest: any = restRes.data;

      if (!cancelled) {
        if (rest.lat && rest.lng) {
          setRestLoc({ lat: rest.lat, lng: rest.lng });
        }
        setRestaurantId(rest.id as string);
      }

      // 2) dane zależne od restauracji: produkty + strefy dostawy
      const [prodRes, dzRes] = await Promise.all([
        supabase
          .from("products")
          .select("id,name,subcategory,description,restaurant_id")
          .eq("restaurant_id", rest.id),
        supabase
          .from("delivery_zones")
          .select("*")
          .eq("restaurant_id", rest.id)
          .order("min_distance_km", { ascending: true }),
      ]);

      if (!cancelled && !prodRes.error && prodRes.data) {
        setProductsDb((prodRes.data as ProductDb[]) || []);
      }
      if (!cancelled && !dzRes.error && dzRes.data) {
        setZones(dzRes.data as Zone[]);
      }
    };

    load();

    return () => {
      cancelled = true;
    };
  }, [restaurantSlug]);

  useEffect(() => {
  if (!isCheckoutOpen || !isLoggedIn || !session?.user?.id) {
    setLoyaltyStickers(null);
    setLoyaltyChoice("keep");
    return;
  }

  let cancelled = false;

  const load = async () => {
    try {
      setLoyaltyLoading(true);
      const { data, error } = await supabaseAuth
        .from("loyalty_accounts")
        .select("stickers")
        .eq("user_id", session.user.id)
        .maybeSingle();

      if (cancelled) return;

      if (error || !data) {
        // brak rekordu = 0 naklejek
        setLoyaltyStickers(0);
      } else {
        const raw = Number((data as any).stickers ?? 0);
        setLoyaltyStickers(Number.isFinite(raw) ? raw : 0);
      }
    } catch {
      if (!cancelled) setLoyaltyStickers(0);
    } finally {
      if (!cancelled) setLoyaltyLoading(false);
    }
  };

  load();

  return () => {
    cancelled = true;
  };
}, [isCheckoutOpen, isLoggedIn, session?.user?.id, supabaseAuth]);

  const [submitting, setSubmitting] = useState(false);
  const [confirmCityOk, setConfirmCityOk] = useState(false);
  const [orderSent, setOrderSent] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [chopsticksQty, setChopsticksQty] = useState<number>(0);

  // Turnstile – remove jako useCallback
  const removeTurnstile = useCallback(() => {
    try {
      if (tsIdRef.current && window.turnstile) window.turnstile.remove(tsIdRef.current);
    } catch {}
    tsIdRef.current = null;
    setTurnstileToken(null);
    setTurnstileError(false);
  }, []);

  // Zamknięcie modala jako stabilny callback
  const closeCheckoutModal = useCallback(() => {
    originalCloseCheckoutModal();
    setPromo(null);
    setPromoError(null);
    setOrderSent(false);
    setErrorMessage(null);
    setConfirmCityOk(false);
    setLegalAccepted(false);
    setSubmitting(false);
    setLoyaltyChoice("keep");
  setLoyaltyStickers(null);
  setLoyaltyLoading(false);
    goToStep(1);
    removeTurnstile();
  }, [originalCloseCheckoutModal, goToStep, removeTurnstile]);

  // ESC zamyka modal + blokada scrolla body
  useEffect(() => {
    if (!isCheckoutOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeCheckoutModal();
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [isCheckoutOpen, closeCheckoutModal]);

  // Turnstile – render jako useCallback
  const renderTurnstile = useCallback(
    (target: HTMLDivElement | null) => {
      if (!TURNSTILE_SITE_KEY || !window.turnstile || !isVisible(target)) return;
      try {
        setTurnstileError(false);
        tsIdRef.current = window.turnstile.render(target!, {
          sitekey: TURNSTILE_SITE_KEY,
          callback: (t: string) => setTurnstileToken(t),
          "error-callback": () => {
            setTurnstileToken(null);
            setTurnstileError(true);
          },
          "expired-callback": () => {
            setTurnstileToken(null);
            try {
              window.turnstile?.reset(tsIdRef.current);
            } catch {}
          },
          "timeout-callback": () => {
            setTurnstileToken(null);
            try {
              window.turnstile?.reset(tsIdRef.current);
            } catch {}
          },
          retry: "auto",
          theme: "auto",
          appearance: "always",
          ["refresh-expired"]: "auto",
        });
      } catch {
        setTurnstileError(true);
      }
    },
    []
  );

  // Turnstile – efekt z pełnymi dependencies
  useEffect(() => {
    if (!TURNSTILE_SITE_KEY || !tsReady) return;
    if (isCheckoutOpen && checkoutStep === 3) {
      renderTurnstile(tsMobileRef.current);
      renderTurnstile(tsDesktopRef.current);
      return () => removeTurnstile();
    }
    removeTurnstile();
  }, [isCheckoutOpen, checkoutStep, tsReady, renderTurnstile, removeTurnstile]);

  const productsByName = useMemo(() => {
    const map = new Map<string, ProductDb>();
    productsDb.forEach((p) => map.set(p.name, p));
    return map;
  }, [productsDb]);

  const productsById = useMemo(() => {
    const map = new Map<string, ProductDb>();
    productsDb.forEach((p) => map.set(p.id, p));
    return map;
  }, [productsDb]);

  const productCategory = useCallback(
    (name: string) => productsByName.get(name)?.subcategory || "",
    [productsByName]
  );

  const resolveProduct = useCallback(
    (item: any): ProductDb | undefined => {
      const pid = item.product_id ?? item.id;
      if (pid && productsById.get(pid)) {
        return productsById.get(pid);
      }
      if (item.baseName && productsByName.get(item.baseName)) {
        return productsByName.get(item.baseName);
      }
      if (item.name && productsByName.get(item.name)) {
        return productsByName.get(item.name);
      }
      return undefined;
    },
    [productsById, productsByName]
  );

  const optionsByCat = useMemo(() => {
    const out: Record<string, string[]> = {};

    productsDb.forEach((p) => {
      const cat = (p.subcategory || "").toLowerCase();
      if (!cat || cat === "specjały" || cat === "zestawy") return;

      const arr = (out[cat] ||= []);
      if (!arr.includes(p.name)) {
        // unikamy duplikatów nazw w obrębie kategorii
        arr.push(p.name);
      }
    });

    Object.values(out).forEach((arr) =>
      arr.sort((a, b) => a.localeCompare(b))
    );

    return out;
  }, [productsDb]);

  const baseTotal = useMemo<number>(() => {
    return items.reduce((acc: number, it: any) => {
      const qty = it.quantity || 1;
      const priceNum =
        typeof it.price === "string" ? parseFloat(it.price) : it.price || 0;
      const productDb = resolveProduct(it);
      const addonsCost = (it.addons ?? []).reduce(
        (sum: number, addon: string) => {
          const unit = computeAddonPrice(addon, productDb || undefined);
          return sum + unit;
        },
        0
      );
      return acc + (priceNum + addonsCost) * qty;
    }, 0);
  }, [items, resolveProduct]);

  const packagingCost = selectedOption ? 3 : 0;
  const subtotal = baseTotal + packagingCost;

  const getItemLineTotal = useCallback(
    (it: any) => {
      const qty = it.quantity || 1;
      const priceNum =
        typeof it.price === "string" ? parseFloat(it.price) : it.price || 0;
      const productDb = resolveProduct(it);
      const addonsCost = (it.addons ?? []).reduce(
        (sum: number, addon: string) => {
          const unit = computeAddonPrice(addon, productDb || undefined);
          return sum + unit;
        },
        0
      );
      return (priceNum + addonsCost) * qty;
    },
    [resolveProduct]
  );

  const isProductEligibleForPromo = useCallback(
    (prodDb: ProductDb, p: NonNullable<Promo>): boolean => {
      const norm = (s: string) => s.toLowerCase().trim();
      const scope = p.apply_scope || "all";
      const cat = norm(prodDb.subcategory || "");
      const name = norm(prodDb.name || "");
      const slug = name.replace(/\s+/g, "-");

      const matchAny = (list: string[] | null) => {
        if (!list || list.length === 0) return false;
        return list.some((raw) => {
          const token = norm(raw);
          if (!token) return false;
          return (
            cat === token ||
            name === token ||
            slug === token ||
            name.includes(token) ||
            slug.includes(token)
          );
        });
      };

      const inCatInclude = matchAny(p.include_categories);
      const inCatExclude = matchAny(p.exclude_categories);
      const inProdInclude = matchAny(p.include_products);
      const inProdExclude = matchAny(p.exclude_products);

      switch (scope) {
        case "include_categories":
          return inCatInclude;
        case "exclude_categories":
          return !inCatExclude;
        case "include_products":
          return inProdInclude;
        case "exclude_products":
          return !inProdExclude;
        case "all":
        default:
          if (inCatExclude || inProdExclude) return false;
          return true;
      }
    },
    []
  );

  const computeDiscountBase = useCallback(
    (p: NonNullable<Promo>): number => {
      return items.reduce((sum, it: any) => {
        const prodDb = resolveProduct(it);
        if (!prodDb) return sum;
        if (!isProductEligibleForPromo(prodDb, p)) return sum;
        const qty = it.quantity || 1;
        const priceNum =
          typeof it.price === "string" ? parseFloat(it.price) : it.price || 0;
        // UWAGA: rabat liczony tylko od ceny produktu (bez dodatków)
        return sum + priceNum * qty;
      }, 0);
    },
    [items, resolveProduct, isProductEligibleForPromo]
  );

  const calcDelivery = async (custLat: number, custLng: number) => {
    if (!restLoc) return;
    try {
      const resp = await fetch(
        `/api/distance?origin=${restLoc.lat},${restLoc.lng}&destination=${custLat},${custLng}`
      );
      const { distance_km, error } = await resp.json();
      if (error) return;

      const zone = zones
        .filter((z) => z.active !== false)
        .find((z) => distance_km >= z.min_distance_km && distance_km <= z.max_distance_km);

      if (!zone) {
        setOutOfRange(true);
        setDeliveryMinOk(false);
        setDeliveryMinRequired(0);
        setDeliveryInfo({ cost: 0, eta: "Poza zasięgiem" });
        return;
      }
      setOutOfRange(false);

      const perKm =
        (zone.pricing_type ?? (zone.min_distance_km === 0 ? "flat" : "per_km")) === "per_km";
      let cost = perKm ? zone.cost * distance_km : zone.cost;
      if (zone.free_over != null && subtotal >= zone.free_over) cost = 0;

      const minOk = subtotal >= (zone.min_order_value || 0);
      setDeliveryMinOk(minOk);
      setDeliveryMinRequired(zone.min_order_value || 0);

      const eta = `${zone.eta_min_minutes}-${zone.eta_max_minutes} min`;
      setDeliveryInfo({ cost: Math.max(0, Math.round(cost * 100) / 100), eta });
    } catch {}
  };

  const onAddressSelect = (address: string, lat: number, lng: number) => {
    setStreet(address);
    if (lat && lng) {
      setCustCoords({ lat, lng });
      calcDelivery(lat, lng);
    }
  };

  const discount = useMemo(() => {
    if (!promo) return 0;
    const base = computeDiscountBase(promo as NonNullable<Promo>);
    if (base <= 0) return 0;
    const val =
      promo.type === "percent"
        ? base * (Number(promo.value) / 100)
        : Number(promo.value || 0);
    const totalCap = baseTotal + packagingCost + (deliveryInfo?.cost || 0);
    return Math.max(0, Math.min(val, totalCap));
  }, [promo, computeDiscountBase, baseTotal, packagingCost, deliveryInfo]);

  const canUseLoyalty4 =
  isLoggedIn &&
  typeof loyaltyStickers === "number" &&
  loyaltyStickers >= 4 &&
  loyaltyStickers < 8;
  const hasAutoLoyaltyDiscount =
  isLoggedIn &&
  typeof loyaltyStickers === "number" &&
  loyaltyStickers >= 8;


  const totalWithDelivery = Math.max(0, subtotal + (deliveryInfo?.cost || 0) - discount);
  const shouldHideOrderActions = Boolean(TURNSTILE_SITE_KEY && turnstileError);

  const productHelpers = {
    addAddon,
    removeAddon,
    swapIngredient,
    removeItem,
    removeWholeItem,
  };

  const guardEmail = () => {
    if (!validEmail) {
      setErrorMessage("Podaj poprawny adres e-mail – wyślemy potwierdzenie i link śledzenia.");
      return false;
    }
    return true;
  };

  const applyPromo = async (codeRaw: string) => {
    setPromoError(null);
    const code = codeRaw.trim();
    if (!code) return;
    if (!restaurantId) {
      setPromoError("Brak przypisanej restauracji do zamówienia.");
      return;
    }
    try {
      const { data, error } = await supabase
        .from("discount_codes")
        .select("*")
        .eq("restaurant_id", restaurantId)
        .eq("active", true)
        .eq("require_code", true)
        .ilike("code", code)
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        // fallback na ewentualny stary endpoint /api/promo/validate
        const currentTotal = baseTotal + packagingCost + (deliveryInfo?.cost || 0);
        const resp = await safeFetch("/api/promo/validate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code, total: currentTotal }),
        });
        if (resp?.valid) {
          const type = resp.type === "amount" ? "amount" : "percent";
          const valueNum = Number(resp.value || 0);
          if (valueNum <= 0) throw new Error("Nieprawidłowa wartość kodu.");
          const legacyPromo: NonNullable<Promo> = {
            id: "legacy",
            code: resp.code || code,
            type,
            value: valueNum,
            apply_scope: "all",
            include_categories: null,
            exclude_categories: null,
            include_products: null,
            exclude_products: null,
            min_order: null,
            require_code: true,
          };
          setPromo(legacyPromo);
          return;
        }
        throw new Error(resp?.message || "Kod nieprawidłowy.");
      }

      const row = data as DiscountCodeRow;
      const promoState = {
        id: row.id,
        code: row.code,
        type: row.type === "amount" ? "amount" : "percent",
        value: Number(row.value || 0),
        apply_scope: (row.apply_scope as ApplyScope) || "all",
        include_categories: row.include_categories || null,
        exclude_categories: row.exclude_categories || null,
        include_products: row.include_products || null,
        exclude_products: row.exclude_products || null,
        min_order: row.min_order,
        require_code: true,
      } as NonNullable<Promo>;

      if (promoState.value <= 0) {
        throw new Error("Nieprawidłowa wartość kodu.");
      }

      const baseForThis = computeDiscountBase(promoState);
      if (baseForThis <= 0) {
        throw new Error("Kod nie dotyczy żadnych produktów w koszyku.");
      }

      const now = new Date();
      if (row.expires_at && new Date(row.expires_at) < now) {
        throw new Error("Kod wygasł.");
      }

      if (
        typeof row.min_order === "number" &&
        row.min_order > 0 &&
        baseForThis < row.min_order
      ) {
        throw new Error(
          `Minimalna wartość zamówienia dla tego kodu to ${row.min_order.toFixed(
            2
          )} zł (liczona tylko z cen produktów).`
        );
      }

      setPromo(promoState);
    } catch (e: any) {
      setPromo(null);
      setPromoError(e.message || "Nie udało się zastosować kodu.");
    }
  };

  const clearPromo = () => {
    setPromo(null);
    setPromoError(null);
  };

  // Automatyczne promocje (require_code = false)
  useEffect(() => {
    if (!restaurantId || items.length === 0) {
      // przy pustym koszyku zostawiamy ewentualny ręczny kod, ale czyścimy auto
      setPromo((current) => (current && current.require_code ? current : null));
      return;
    }

    let cancelled = false;

    const loadAuto = async () => {
      try {
        const { data, error } = await supabase
          .from("discount_codes")
          .select("*")
          .eq("restaurant_id", restaurantId)
          .eq("active", true)
          .eq("require_code", false);

        if (error || !data) return;

        const rows = data as DiscountCodeRow[];
        let best: NonNullable<Promo> | null = null;
        let bestDiscount = 0;

        rows.forEach((row) => {
          const promoState = {
            id: row.id,
            code: row.code,
            type: row.type === "amount" ? "amount" : "percent",
            value: Number(row.value || 0),
            apply_scope: (row.apply_scope as ApplyScope) || "all",
            include_categories: row.include_categories || null,
            exclude_categories: row.exclude_categories || null,
            include_products: row.include_products || null,
            exclude_products: row.exclude_products || null,
            min_order: row.min_order,
            require_code: false,
          } as NonNullable<Promo>;

          if (promoState.value <= 0) return;

          const base = computeDiscountBase(promoState);
          if (base <= 0) return;

          const now = new Date();
          if (row.expires_at && new Date(row.expires_at) < now) return;

          if (
            typeof row.min_order === "number" &&
            row.min_order > 0 &&
            base < row.min_order
          ) {
            return;
          }

          const disc =
            promoState.type === "percent"
              ? base * (promoState.value / 100)
              : promoState.value;

          if (disc > bestDiscount) {
            bestDiscount = disc;
            best = promoState;
          }
        });

        if (cancelled) return;

        setPromo((current) => {
          // ręcznie wpisany kod ma priorytet
          if (current && current.require_code) return current;
          return best;
        });
      } catch {
        // brak auto-promki = cisza
      }
    };

    loadAuto();

    return () => {
      cancelled = true;
    };
  }, [restaurantId, items, computeDiscountBase]);

  const ensureFreshToken = async () => {
    if (!TURNSTILE_SITE_KEY) return true;
    if (turnstileToken) return true;
    try {
      if (window.turnstile && tsIdRef.current) window.turnstile.reset(tsIdRef.current);
      await new Promise((r) => setTimeout(r, 400));
      return !!turnstileToken;
    } catch {
      return false;
    }
  };

  const handleSubmitOrder = async () => {
    if (submitting) return;
    setErrorMessage(null);

    if (!selectedOption) {
      setErrorMessage("Wybierz sposób odbioru.");
      return;
    }
    if (!legalAccepted) {
      setErrorMessage("Zaznacz akceptację regulaminu i polityki prywatności.");
      return;
    }
    if (!confirmCityOk) {
      setErrorMessage("Potwierdź miasto restauracji przed złożeniem zamówienia.");
      return;
    }

    const chk = isOpenFor(restaurantSlug);
    if (!chk.open) {
      setErrorMessage(
        `Zamówienia dla ${restaurantCityLabel} przyjmujemy dziś ${chk.label}.`
      );
      return;
    }

    if (selectedOption === "delivery" && deliveryTimeOption === "schedule") {
      const [h, m] = scheduledTime.split(":").map(Number);
      if (!Number.isFinite(h) || !Number.isFinite(m)) {
        setErrorMessage("Podaj prawidłową godzinę dostawy.");
        return;
      }
      const nowZoned = toZonedTime(new Date(), tz);
      const dt = new Date(nowZoned);
      dt.setHours(h, m, 0, 0);
      if (dt.getTime() < nowZoned.getTime()) {
        dt.setDate(dt.getDate() + 1);
      }
      const diffMinutes = (dt.getTime() - nowZoned.getTime()) / 60000;
      if (diffMinutes < MIN_SCHEDULE_MINUTES) {
        setErrorMessage(
          `Przy wyborze dostawy „na godzinę” minimalny czas to ${MIN_SCHEDULE_MINUTES} minut od teraz.`
        );
        return;
      }
    }

    if (!guardEmail()) return;
    if (TURNSTILE_SITE_KEY && !(await ensureFreshToken())) {
      setErrorMessage("Weryfikacja formularza nie powiodła się.");
      return;
    }

    if (selectedOption === "delivery") {
      if (REQUIRE_AUTOCOMPLETE && !custCoords) {
        setErrorMessage(
          "Wybierz adres z listy (podpowiedzi Google), aby potwierdzić dostawę."
        );
        return;
      }
      if (outOfRange) {
        setErrorMessage("Adres jest poza zasięgiem dostawy.");
        return;
      }
      if (!deliveryMinOk) {
        setErrorMessage(
          `Minimalna wartość zamówienia dla tej strefy to ${deliveryMinRequired.toFixed(2)} zł.`
        );
        return;
      }
    }

    setSubmitting(true);
    try {
      const client_delivery_time = buildClientDeliveryTime(
        selectedOption,
        deliveryTimeOption,
        scheduledTime
      );
      const slug = restaurantSlug;

      try {
        await fetch(`/api/restaurants/ensure-cookie?restaurant=${encodeURIComponent(slug)}`, {
          method: "GET",
          credentials: "same-origin",
        });
      } catch {}

      const orderPayload: any = {
        selected_option: selectedOption,
        payment_method:
          selectedOption === "delivery" ? "Gotówka u kierowcy" : "Gotówka przy odbiorze",
        user: isLoggedIn ? session!.user.id : null,
        name,
        phone,
        contact_email: effectiveEmail,
        delivery_cost: deliveryInfo?.cost || 0,
        total_price: totalWithDelivery,
        discount_amount: discount || 0,
        promo_code: promo?.code || (promo && !promo.require_code ? "AUTO" : null),
        legal_accept: {
          terms_version: TERMS_VERSION,
          privacy_version: TERMS_VERSION,
          marketing_opt_in: false,
        },
        status: "placed",
        notice_payment:
          selectedOption === "delivery" ? "Płatność wyłącznie gotówką u kierowcy" : null,
        chopsticks_qty: Math.max(0, Math.min(10, Number(chopsticksQty) || 0)),
        reservation_id: reservationId || null,
        loyalty_choice: canUseLoyalty4 ? loyaltyChoice : null,
        loyalty_stickers_before:
    typeof loyaltyStickers === "number" ? loyaltyStickers : null,
      };

      if (selectedOption === "delivery") {
        orderPayload.street = street || null;
        orderPayload.postal_code = postalCode || null;
        orderPayload.city = city || null;
        orderPayload.flat_number = flatNumber || null;
        orderPayload.client_delivery_time = client_delivery_time;
        if (custCoords) {
          orderPayload.delivery_lat = custCoords.lat;
          orderPayload.delivery_lng = custCoords.lng;
        }
      } else if (optionalAddress.trim()) {
        orderPayload.address = optionalAddress.trim();
      }

       const itemsPayload = items.map((item: any, index: number) => {
        const product = resolveProduct(item);

        // NOWE: zamiany w zestawie + dodatki per rolka
        const setSwaps = buildSetSwapsPayload(item, product);

        // tekst z notatki użytkownika + tekst z zamian
        const userNote = notes[index] || "";
        const swapsNote = buildSetSwapsNote(setSwaps);
        const combinedNote =
          userNote && swapsNote
            ? `${userNote} | ${swapsNote}`
            : userNote || swapsNote || "";

        return {
          product_id: product?.id ?? item.product_id ?? item.id ?? null,
          name: item.name,
          quantity: item.quantity || 1,
          unit_price: item.price,
          options: {
            addons: item.addons,
            swaps: item.swaps,
            set_swaps: setSwaps.length ? setSwaps : undefined, // struktura do panelu
            note: combinedNote, // to pole czyta backend (opt.note)
            restaurant: slug,
          },
        };
      });

      await safeFetch(`/api/orders/create?restaurant=${encodeURIComponent(slug)}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "cf-turnstile-response": turnstileToken || "",
          "x-restaurant-slug": slug,
        },
        body: JSON.stringify({ orderPayload, itemsPayload, turnstileToken, restaurant: slug }),
      });

      clearCart();
      setOrderSent(true);
    } catch (err: any) {
      setErrorMessage(err.message || "Wystąpił błąd podczas składania zamówienia.");
      try {
        if (window.turnstile && tsIdRef.current) window.turnstile.reset(tsIdRef.current);
      } catch {}
    } finally {
      setSubmitting(false);
    }
  };

 if (!isClient || !isCheckoutOpen) return null;

const OPTIONS: { key: OrderOption; label: string; Icon: any }[] = [
  { key: "takeaway", label: "Na wynos", Icon: ShoppingBag },
  { key: "delivery", label: "Dostawa", Icon: Truck },
];

const LegalConsent = (
  <label className="flex items-start gap-2 text-xs leading-5 text-black">
    <input
      type="checkbox"
      checked={legalAccepted}
      onChange={(e) => setLegalAccepted(e.target.checked)}
      className="mt-0.5"
    />
    <span>
      Akceptuję{" "}
      <a
        href="/legal/regulamin"
        target="_blank"
        rel="noopener noreferrer"
        className="underline"
      >
        Regulamin
      </a>{" "}
      oraz{" "}
      <a
        href="/legal/polityka-prywatnosci"
        target="_blank"
        rel="noopener noreferrer"
        className="underline"
      >
        Politykę prywatności
      </a>{" "}
      (v{TERMS_VERSION}).
    </span>
  </label>
);

return (
  <>
    {TURNSTILE_SITE_KEY && (
      <Script
        id="cf-turnstile"
        src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit"
        async
        defer
        strategy="afterInteractive"
        onLoad={() => setTsReady(true)}
      />
    )}

    <div
      className="fixed inset-0 z-[58] bg-black/70 grid place-items-stretch lg:place-items-center p-0 lg:p-4"
      role="dialog"
      aria-modal="true"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) closeCheckoutModal();
      }}
    >
      <div
        className="w-full max-w-5xl bg-white text-black shadow-2xl grid grid-rows-[auto,1fr] h-full lg:h-auto lg:max-h-[90vh]"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-black/10">
          <h2 className="text-xl font-semibold">
            Zamówienie — {restaurantCityLabel}
          </h2>
          {!orderSent && (
            <button
              aria-label="Zamknij"
              onClick={closeCheckoutModal}
              className="p-2 rounded-full hover:bg-black/5"
            >
              <X size={20} />
            </button>
          )}
        </div>

        <div className="overflow-y-auto overscroll-contain">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-6 p-6">
            <div>
              {orderSent ? (
                <div className="min-h-[320px] flex flex-col items-center justify-center text-center space-y-5 px-4">
                  <div className="bg-white p-4 rounded-2xl shadow flex flex-col items-center gap-2">
                    <div className="bg-white p-3 rounded-xl">
                      <QRCode value={thanksQrUrl} size={170} />
                    </div>
                    <p className="text-xs text-black/60 max-w-xs">
                      Zeskanuj kod lub kliknij poniższy przycisk, aby ocenić
                      lokal w Google.
                    </p>
                  </div>
                  <h3 className="text-2xl font-bold">
                    Dziękujemy za zamówienie!
                  </h3>
                  <p className="text-black/70">
                    Potwierdzenie i link do śledzenia wysłaliśmy na Twój adres
                    e-mail.
                  </p>
                  <div className="flex justify-center gap-3 flex-wrap">
                    <button
                      onClick={() => window.open(thanksQrUrl, "_blank")}
                      className={`px-4 py-2 rounded-xl ${accentBtn}`}
                    >
                      Zostaw opinię w Google
                    </button>
                    <button
                      onClick={closeCheckoutModal}
                      className="px-4 py-2 rounded-xl border border-black/15"
                    >
                      Zamknij
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {errorMessage && (
                    <div className="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-2 text-red-700">
                      {errorMessage}
                    </div>
                  )}

                  {/* KROK 1 MOBILE: lista produktów */}
                  {isMobile && checkoutStep === 1 && (
                    <div className="space-y-6">
                      <h3 className="text-2xl font-bold">Wybrane produkty</h3>

                      <div className="space-y-3 max-h-[360px] overflow-y-auto">
                        {items.map((item, idx) => (
                          <div key={idx} className="space-y-1">
                            <ProductItem
                              prod={item}
                              productCategory={productCategory}
                              productsDb={productsDb}
                              optionsByCat={optionsByCat}
                              restaurantSlug={restaurantSlug}
                              helpers={productHelpers}
                            />
                            <textarea
                              className="w-full text-xs border border-black/15 rounded-xl px-2 py-1 bg-white"
                              placeholder="Notatka do produktu"
                              value={notes[idx] || ""}
                              onChange={(e) =>
                                setNotes({ ...notes, [idx]: e.target.value })
                              }
                            />
                          </div>
                        ))}
                        {items.length === 0 && (
                          <p className="text-center text-black/60">
                            Brak produktów w koszyku.
                          </p>
                        )}
                      </div>

                      <ChopsticksControl
                        value={chopsticksQty}
                        onChange={setChopsticksQty}
                      />

                      <div className="pt-2 border-t border-black/10 flex justify-end">
                        <button
                          onClick={nextStep}
                          disabled={items.length === 0}
                          className={`min-w-[160px] py-2 rounded-xl font-semibold ${accentBtn} disabled:opacity-50`}
                        >
                          Dalej →
                        </button>
                      </div>
                    </div>
                  )}

                  {/* KROK 1 DESKTOP / KROK 2 MOBILE: sposób odbioru */}
                  {((!isMobile && checkoutStep === 1) ||
                    (isMobile && checkoutStep === 2)) && (
                    <div className="space-y-6">
                      <h3 className="text-2xl font-bold">Sposób odbioru</h3>

                      <div className="grid grid-cols-2 gap-3">
                        {OPTIONS.map(({ key, label, Icon }) => (
                          <button
                            key={key}
                            onClick={() => setSelectedOption(key)}
                            className={clsx(
                              "flex flex-col items-center justify-center border px-3 py-4 transition",
                              selectedOption === key
                                ? "bg-yellow-400 text-black border-yellow-500"
                                : "bg-gray-50 text-black border-black/10 hover:bg-gray-100"
                            )}
                          >
                            <Icon size={22} />
                            <span className="mt-1 text-sm font-medium">
                              {label}
                            </span>
                          </button>
                        ))}
                      </div>

                      {selectedOption === "delivery" && (
                        <div className="rounded-xl bg-yellow-50 border border-yellow-200 p-3 text-sm">
                          Płatność: <b>gotówka u kierowcy</b>.
                        </div>
                      )}

                      {selectedOption === "delivery" && (
                        <div className="space-y-2">
                          <h4 className="font-semibold">Czas dostawy</h4>
                          <div className="flex flex-wrap gap-6 items-center">
                            <label className="flex items-center gap-2">
                              <input
                                type="radio"
                                name="timeOption"
                                value="asap"
                                checked={deliveryTimeOption === "asap"}
                                onChange={() =>
                                  setDeliveryTimeOption("asap")
                                }
                              />
                              <span>Jak najszybciej</span>
                            </label>
                            <label className="flex items-center gap-2">
                              <input
                                type="radio"
                                name="timeOption"
                                value="schedule"
                                checked={deliveryTimeOption === "schedule"}
                                onChange={() =>
                                  setDeliveryTimeOption("schedule")
                                }
                              />
                              <span>Na godzinę</span>
                            </label>
                            {deliveryTimeOption === "schedule" && (
                              <input
                                type="time"
                                className="border border-black/15 rounded-xl px-2 py-1"
                                min={timeMin}
                                max={timeMax}
                                value={scheduledTime}
                                onChange={(e) =>
                                  setScheduledTime(e.target.value)
                                }
                              />
                            )}
                          </div>
                          <p className="text-xs text-black/60">
                            Dzisiejsze godziny w {restaurantCityLabel}:{" "}
                            {openInfo.label}
                          </p>
                        </div>
                      )}

                      <div className="flex justify-between gap-3 pt-2 border-t border-black/10">
                        {isMobile && (
                          <button
                            type="button"
                            onClick={() => goToStep(1)}
                            className="px-4 py-2 rounded-xl border border-black/15"
                          >
                            ← Cofnij
                          </button>
                        )}
                        <div className="flex-1 flex justify-end">
                          <button
                            onClick={nextStep}
                            disabled={!selectedOption}
                            className={`min-w-[220px] py-2 rounded-xl font-semibold ${accentBtn} disabled:opacity-50`}
                          >
                            Dalej →
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* KROK 2 DESKTOP / KROK 3 MOBILE: dane kontaktowe + podsumowanie mobile */}
                  {((!isMobile && checkoutStep === 2) ||
                    (isMobile && checkoutStep === 3)) && (
                    <div className="space-y-6">
                      <h3 className="text-2xl font-bold">Dane kontaktowe</h3>

                      {selectedOption === "delivery" && (
                        <>
                          <AddressAutocomplete
                            onAddressSelect={onAddressSelect}
                            setCity={setCity}
                            setPostalCode={setPostalCode}
                            setFlatNumber={setFlatNumber}
                          />

                          {/* INFO: gdy nie ma adresu na liście */}
                          <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-black/70">
                            <span>Nie możesz znaleźć swojego adresu?</span>
                            {restaurantPhone && (
                              <a
                                href={`tel:${restaurantPhone.replace(
                                  /\s+/g,
                                  ""
                                )}`}
                                className="inline-flex items-center justify-center rounded-full border border-black/15 px-3 py-1 font-semibold hover:bg-gray-100 text-black"
                              >
                                Zadzwoń do nas
                              </a>
                            )}
                          </div>

                          <p className="text-xs text-black/60">
                            Najpierw wybierz adres z listy Google – dopiero
                            wtedy pola poniżej odblokują się do edycji.
                          </p>

                          <div className="grid grid-cols-1 gap-2">
                            <input
                              type="text"
                              placeholder="Adres (ulica i numer domu)"
                              className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white disabled:bg-gray-100 disabled:text-black/50 disabled:cursor-not-allowed"
                              value={street}
                              onChange={(e) => setStreet(e.target.value)}
                              disabled={
                                REQUIRE_AUTOCOMPLETE && !custCoords
                              }
                            />
                            <div className="flex gap-2">
                              <input
                                type="text"
                                placeholder="Numer mieszkania (opcjonalnie)"
                                className="flex-1 px-3 py-2 border border-black/15 rounded-xl bg-white disabled:bg-gray-100 disabled:text-black/50 disabled:cursor-not-allowed"
                                value={flatNumber}
                                onChange={(e) =>
                                  setFlatNumber(e.target.value)
                                }
                                disabled={
                                  REQUIRE_AUTOCOMPLETE && !custCoords
                                }
                              />
                              <input
                                type="text"
                                placeholder="Kod pocztowy"
                                className="flex-1 px-3 py-2 border border-black/15 rounded-xl bg-white disabled:bg-gray-100 disabled:text-black/50 disabled:cursor-not-allowed"
                                value={postalCode}
                                onChange={(e) =>
                                  setPostalCode(e.target.value)
                                }
                                disabled={
                                  REQUIRE_AUTOCOMPLETE && !custCoords
                                }
                              />
                            </div>
                            <input
                              type="text"
                              placeholder="Miasto"
                              className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white disabled:bg-gray-100 disabled:text-black/50 disabled:cursor-not-allowed"
                              value={city}
                              onChange={(e) => setCity(e.target.value)}
                              disabled={
                                REQUIRE_AUTOCOMPLETE && !custCoords
                              }
                            />
                            {REQUIRE_AUTOCOMPLETE && !custCoords && (
                              <p className="text-xs text-red-600">
                                Wpisanie adresu ręcznie jest zablokowane –
                                wybierz pozycję z listy podpowiedzi Google.
                              </p>
                            )}
                          </div>
                        </>
                      )}

                      {selectedOption === "takeaway" && (
                        <div className="rounded-xl bg-gray-50 border border-black/10 p-3 text-sm">
                          Odbiór osobisty w lokalu. Płatność przy odbiorze
                          gotówką.
                        </div>
                      )}

                      <div className="grid grid-cols-1 gap-2">
                        <input
                          type="text"
                          placeholder="Imię"
                          className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                        />
                        <input
                          type="tel"
                          placeholder="Telefon"
                          className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                        />
                        {selectedOption === "takeaway" && (
                          <input
                            type="text"
                            placeholder="Uwagi do odbioru (opcjonalnie)"
                            className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white"
                            value={optionalAddress}
                            onChange={(e) =>
                              setOptionalAddress(e.target.value)
                            }
                          />
                        )}
                        <input
                          type="email"
                          placeholder="Email (wymagany do potwierdzenia)"
                          className="w-full px-3 py-2 border border-black/15 rounded-xl bg-white"
                          value={contactEmail}
                          onChange={(e) =>
                            setContactEmail(e.target.value)
                          }
                        />
                        {contactEmail !== "" && !validEmail && (
                          <p className="text-xs text-red-600">
                            Podaj poprawny adres e-mail.
                          </p>
                        )}
                      </div>

                      <div className="flex justify-between mt-2">
                        <button
                          onClick={() => goToStep(isMobile ? 2 : 1)}
                          className="px-4 py-2 rounded-xl border border-black/15"
                        >
                          ← Cofnij
                        </button>

                        {/* Na desktopie dalej przechodzimy do kroku 3 (podsumowanie).
                            Na mobile nie ma kroku 4 – zamawianie kończymy przyciskiem
                            „✅ Zamawiam” niżej. */}
                        {!isMobile && (
                          <button
                            onClick={nextStep}
                            disabled={
                              !name ||
                              !phone ||
                              !validEmail ||
                              (selectedOption === "delivery" &&
                                (!street ||
                                  !postalCode ||
                                  !city ||
                                  (REQUIRE_AUTOCOMPLETE &&
                                    !custCoords)))
                            }
                            className={`px-4 py-2 rounded-xl text-white font-semibold ${accentBtn} disabled:opacity-50`}
                          >
                            Dalej →
                          </button>
                        )}
                      </div>

                      {isMobile && (
                        <p className="mt-2 text-xs text-black/60">
                          Przewiń niżej, aby zobaczyć podsumowanie, zgody i
                          przycisk „✅ Zamawiam”.
                        </p>
                      )}

                      {/* MOBILE: podsumowanie + zgody + Turnstile */}
                      {isMobile && (
                        <div className="mt-3 space-y-4">
                          {/* Podsumowanie cen */}
                          <div className="rounded-2xl border border-black/10 bg-white p-4 space-y-2">
                            <h4 className="text-lg font-semibold">
                              Podsumowanie
                            </h4>
                            <div className="space-y-1 text-sm">
  <div className="flex justify-between">
    <span>Produkty:</span>
    <span>{baseTotal.toFixed(2)} zł</span>
  </div>
  {selectedOption && (
    <div className="flex justify-between">
      <span>Opakowanie:</span>
      <span>3.00 zł</span>
    </div>
  )}
  {deliveryInfo && (
    <div className="flex justify-between">
      <span>Dostawa:</span>
      <span>{deliveryInfo.cost.toFixed(2)} zł</span>
    </div>
  )}
</div>

{/* LOYALTY – MOBILE */}
{isLoggedIn && (
  <div className="mt-2">
    {loyaltyLoading ? (
      <p className="text-[11px] text-black/60">
        Sprawdzamy Twoje naklejki...
      </p>
    ) : (
      typeof loyaltyStickers === "number" && (
        <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs space-y-2">
          <div>
            Masz <b>{loyaltyStickers}</b> naklejek w programie lojalnościowym.
          </div>

          {canUseLoyalty4 && (
            <div className="space-y-1">
              <div className="font-semibold text-sm">
                Czy chcesz wymienić 4 naklejki na darmową rolkę?
              </div>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="loyalty_choice_mobile"
                  value="use_4"
                  checked={loyaltyChoice === "use_4"}
                  onChange={() => setLoyaltyChoice("use_4")}
                />
                <span>Tak, wykorzystaj 4 naklejki w tym zamówieniu.</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="loyalty_choice_mobile"
                  value="keep"
                  checked={loyaltyChoice === "keep"}
                  onChange={() => setLoyaltyChoice("keep")}
                />
                <span>Nie teraz, zbieram dalej.</span>
              </label>
            </div>
          )}

          {!canUseLoyalty4 && hasAutoLoyaltyDiscount && (
            <div className="font-semibold text-sm">
              Masz już co najmniej 8 naklejek – rabat lojalnościowy doliczymy przy realizacji zamówienia.
            </div>
          )}
        </div>
      )
    )}
  </div>
)}

<PromoSection
  promo={promo}
  promoError={promoError}
  onApply={applyPromo}
  onClear={clearPromo}
/>

                            {discount > 0 && (
                              <div className="flex justify-between text-sm text-green-700">
                                <span>Rabat:</span>
                                <span>-{discount.toFixed(2)} zł</span>
                              </div>
                            )}

                            <div className="flex justify-between font-semibold border-t border-black/10 pt-2">
                              <span>RAZEM:</span>
                              <span>
                                {totalWithDelivery.toFixed(2)} zł
                              </span>
                            </div>

                            {deliveryInfo && (
                              <p className="text-[11px] text-black/60 text-center mt-1">
                                ETA: {deliveryInfo.eta}
                              </p>
                            )}
                          </div>

                          {/* Potwierdzenia + Turnstile */}
                          <div className="rounded-2xl border border-black/10 bg-gray-50 p-4 space-y-3">
                            <h4 className="text-lg font-semibold">
                              Potwierdzenia
                            </h4>
                            <div className="space-y-3">
                              {LegalConsent}
                              <label className="flex items-start gap-2 text-xs leading-5 text-black">
                                <input
                                  type="checkbox"
                                  checked={confirmCityOk}
                                  onChange={(e) =>
                                    setConfirmCityOk(e.target.checked)
                                  }
                                  className="mt-0.5"
                                />
                                <span>
                                  Uwaga: składasz zamówienie do restauracji w{" "}
                                  <b>{restaurantCityLabel}</b>. Potwierdzam,
                                  że to prawidłowe miasto.
                                </span>
                              </label>

                              {TURNSTILE_SITE_KEY ? (
                                <div>
                                  <h4 className="font-semibold mb-1">
                                    Weryfikacja
                                  </h4>
                                  {turnstileError ? (
                                    <p className="text-sm text-red-600">
                                      Nie udało się załadować weryfikacji.
                                    </p>
                                  ) : (
                                    <>
                                      <div ref={tsMobileRef} />
                                      <p className="text-[11px] text-black/60 mt-1">
                                        Chronimy formularz przed botami.
                                      </p>
                                    </>
                                  )}
                                </div>
                              ) : (
                                <p className="text-[11px] text-black/60">
                                  Weryfikacja Turnstile wyłączona (brak
                                  klucza).
                                </p>
                              )}
                            </div>

                            {!shouldHideOrderActions && (
                              <button
                                onClick={handleSubmitOrder}
                                disabled={
                                  submitting ||
                                  !legalAccepted ||
                                  !confirmCityOk ||
                                  (TURNSTILE_SITE_KEY
                                    ? !turnstileToken
                                    : false)
                                }
                                className={`w-full mt-2 py-2 rounded-xl font-semibold ${accentBtn} disabled:opacity-50`}
                              >
                                {submitting ? (
                                  <span className="flex items-center justify-center gap-2">
                                    <span className="h-4 w-4 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                                    Przetwarzanie...
                                  </span>
                                ) : (
                                  "✅ Zamawiam"
                                )}
                              </button>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* KROK 3 DESKTOP: podsumowanie + pałeczki */}
                  {!isMobile && checkoutStep === 3 && (
                    <div className="space-y-6">
                      <h3 className="text-2xl font-bold text-center">
                        Podsumowanie
                      </h3>

                      {selectedOption === "delivery" && (
                        <div className="rounded-xl bg-yellow-50 border border-yellow-200 p-3 text-sm text-center">
                          <b>Płatność wyłącznie gotówką u kierowcy.</b>
                        </div>
                      )}

                      <div className="flex flex-col gap-6">
                        <div className="space-y-3 max-h-[360px] overflow-y-auto">
                          {items.map((item, idx) => (
                            <div key={idx} className="space-y-1">
                              <ProductItem
                                prod={item}
                                productCategory={productCategory}
                                productsDb={productsDb}
                                optionsByCat={optionsByCat}
                                restaurantSlug={restaurantSlug}
                                helpers={productHelpers}
                              />
                              <textarea
                                className="w-full text-xs border border-black/15 rounded-xl px-2 py-1 bg-white"
                                placeholder="Notatka do produktu"
                                value={notes[idx] || ""}
                                onChange={(e) =>
                                  setNotes({
                                    ...notes,
                                    [idx]: e.target.value,
                                  })
                                }
                              />
                            </div>
                          ))}
                          {items.length === 0 && (
                            <p className="text-center text-black/60">
                              Brak produktów w koszyku.
                            </p>
                          )}
                        </div>
                      </div>

                      <ChopsticksControl
                        value={chopsticksQty}
                        onChange={setChopsticksQty}
                      />
                    </div>
                  )}
                </>
              )}
            </div>

            {/* PASEK BOCZNY PODSUMOWANIA (DESKTOP) */}
            {!orderSent && (
              <aside className="hidden lg:flex">
                <div className="sticky top-4 w-[340px] mx-auto border border-black/10 bg-white p-5 shadow-xl text-black space-y-4 text-left">
                  <h4 className="text-xl font-bold text-center">
                    Podsumowanie
                  </h4>

                  <div className="space-y-2 max-h-[200px] overflow-y-auto">
                    {items.length === 0 ? (
                      <p className="text-sm text-black/60 text-center">
                        Brak produktów.
                      </p>
                    ) : (
                      items.map((it: any, i: number) => {
                        const label = withCategoryPrefix(
                          it.name,
                          productCategory(it.name)
                        );
                        return (
                          <div
                            key={i}
                            className="flex justify-between text-sm"
                          >
                            <span className="truncate pr-2">
                              {label} ×{it.quantity || 1}
                            </span>
                            <span>
                              {getItemLineTotal(it).toFixed(2)} zł
                            </span>
                          </div>
                        );
                      })
                    )}
                  </div>

                  <div className="flex justify-between">
                    <span>Produkty:</span>
                    <span>{baseTotal.toFixed(2)} zł</span>
                  </div>
                  {selectedOption && (
                    <div className="flex justify-between">
                      <span>Opakowanie:</span>
                      <span>3.00 zł</span>
                    </div>
                  )}
                 {deliveryInfo && (
  <div className="flex justify-between">
    <span>Dostawa:</span>
    <span>{deliveryInfo.cost.toFixed(2)} zł</span>
  </div>
)}

{/* LOYALTY – DESKTOP */}
{isLoggedIn && (
  <div className="mt-2">
    {loyaltyLoading ? (
      <p className="text-[11px] text-black/60 text-center">
        Sprawdzamy Twoje naklejki...
      </p>
    ) : (
      typeof loyaltyStickers === "number" && (
        <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs space-y-2">
          <div className="text-center">
            Masz <b>{loyaltyStickers}</b> naklejek w programie lojalnościowym.
          </div>

          {canUseLoyalty4 && (
            <div className="space-y-1">
              <div className="font-semibold text-sm text-center">
                Czy chcesz wymienić 4 naklejki na darmową rolkę?
              </div>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="loyalty_choice_desktop"
                  value="use_4"
                  checked={loyaltyChoice === "use_4"}
                  onChange={() => setLoyaltyChoice("use_4")}
                />
                <span>Tak, wykorzystaj 4 naklejki w tym zamówieniu.</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="loyalty_choice_desktop"
                  value="keep"
                  checked={loyaltyChoice === "keep"}
                  onChange={() => setLoyaltyChoice("keep")}
                />
                <span>Nie teraz, zbieram dalej.</span>
              </label>
            </div>
          )}

          {!canUseLoyalty4 && hasAutoLoyaltyDiscount && (
            <div className="font-semibold text-sm text-center">
              Masz już co najmniej 8 naklejek – rabat lojalnościowy doliczymy przy realizacji zamówienia.
            </div>
          )}
        </div>
      )
    )}
  </div>
)}

<PromoSection
  promo={promo}
  promoError={promoError}
  onApply={applyPromo}
  onClear={clearPromo}
/>
                  {discount > 0 && (
                    <div className="flex justify-between text-green-700">
                      <span>Rabat:</span>
                      <span>-{discount.toFixed(2)} zł</span>
                    </div>
                  )}
                  <div className="flex justify-between font-semibold border-t pt-2">
                    <span>RAZEM:</span>
                    <span>{totalWithDelivery.toFixed(2)} zł</span>
                  </div>
                  {deliveryInfo && (
                    <p className="text-xs text-black/60 text-center">
                      ETA: {deliveryInfo.eta}
                    </p>
                  )}

                  <div className="space-y-2">
                    {LegalConsent}
                    <label className="flex items-start gap-2 text-xs leading-5 text-black">
                      <input
                        type="checkbox"
                        checked={confirmCityOk}
                        onChange={(e) =>
                          setConfirmCityOk(e.target.checked)
                        }
                        className="mt-0.5"
                      />
                      <span>
                        Uwaga: składasz zamówienie do restauracji w{" "}
                        <b>{restaurantCityLabel}</b>. Potwierdzam, że to
                        prawidłowe miasto.
                      </span>
                    </label>

                    <p className="text-[11px] text-black/60 text-center">
                      Dzisiejsze godziny w {restaurantCityLabel}:{" "}
                      {openInfo.label}
                    </p>

                    {TURNSTILE_SITE_KEY ? (
                      <div className="mt-1">
                        <h4 className="font-semibold mb-1">
                          Weryfikacja
                        </h4>
                        {turnstileError ? (
                          <p className="text-sm text-red-600">
                            Nie udało się załadować weryfikacji.
                          </p>
                        ) : (
                          <>
                            <div ref={tsDesktopRef} />
                            <p className="text-[11px] text-black/60 mt-1">
                              Chronimy formularz przed botami.
                            </p>
                          </>
                        )}
                      </div>
                    ) : (
                      <p className="text-[11px] text-black/60">
                        Weryfikacja Turnstile wyłączona (brak klucza).
                      </p>
                    )}

                    {!shouldHideOrderActions && (
                      <button
                        onClick={handleSubmitOrder}
                        disabled={
                          submitting ||
                          !legalAccepted ||
                          !confirmCityOk ||
                          (TURNSTILE_SITE_KEY
                            ? !turnstileToken
                            : false)
                        }
                        className={`w-full mt-2 py-2 rounded-xl font-semibold ${accentBtn} disabled:opacity-50`}
                      >
                        {submitting ? (
                          <span className="flex items-center justify-center gap-2">
                            <span className="h-4 w-4 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                            Przetwarzanie...
                          </span>
                        ) : (
                          "✅ Zamawiam"
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </aside>
            )}
          </div>
        </div>
      </div>
    </div>
  </>
);
}
