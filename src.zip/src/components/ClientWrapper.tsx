"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import Header from "./Header";
import FloatingQuickActions from "./FloatingQuickActions";
import CheckoutModal from "./menu/CheckoutModal";

export default function ClientWrapper({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isAdminRoute = pathname.startsWith("/admin");

  // 3.3 – REJESTRACJA SERVICE WORKERA (dla całej aplikacji)
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator)) return;

    navigator.serviceWorker
      .register("/sw.js", { scope: "/" })
      .then((reg) => {
        console.log("[sw] Zarejestrowano service workera:", reg.scope);
      })
      .catch((err) => {
        console.error("[sw] Błąd rejestracji:", err);
      });
  }, []);

  return (
    <>
      {!isAdminRoute && <Header />}
      {children}
      {!isAdminRoute && <FloatingQuickActions />}
      {!isAdminRoute && <CheckoutModal />}
    </>
  );
}
